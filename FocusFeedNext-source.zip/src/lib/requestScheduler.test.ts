import { afterEach, describe, expect, it, vi } from 'vitest';
import { RequestScheduler, type RequestContext } from '../../src-tauri/plugins/ios-reader/transaction/scheduler';
const context = (id:string,priority=1,generation=1,ms=1000):RequestContext => ({id,priority,generation,deadline:Date.now()+ms});
afterEach(() => vi.useRealTimers());
describe('native provider scheduler', () => {
  it('prioritizes user work and coalesces identical reads with one active operation', async () => {
    const scheduler = new RequestScheduler(); const order:string[] = []; let active=0,max=0;
    const run = (id:string) => async () => { max=Math.max(max,++active); order.push(id); await Promise.resolve(); active--; return id; };
    const nearby=scheduler.enqueue(context('near',2),false,'same',run('near'));
    const duplicate=scheduler.enqueue(context('duplicate',2),false,'same',run('duplicate'));
    const action=scheduler.enqueue(context('action',0),true,'write',run('action'));
    const maintenance=scheduler.enqueue(context('maintenance',3),false,'health',run('health'));
    expect(duplicate).toBe(nearby); await Promise.all([nearby,duplicate,action,maintenance]);
    expect(order).toEqual(['action','near','health']); expect(max).toBe(1);
  });
  it('expires a queued request without executing it later', async () => {
    vi.useFakeTimers(); const scheduler=new RequestScheduler(); let release!:()=>void;
    const first=scheduler.enqueue(context('first'),false,'first',()=>new Promise<void>(resolve=>{release=resolve;}));
    const run=vi.fn(async()=>1); const queued=scheduler.enqueue(context('queued',2,1,10),false,'queued',run);
    const rejected=expect(queued).rejects.toThrow('expired'); await vi.advanceTimersByTimeAsync(20); await rejected;
    release(); await first; await Promise.resolve(); expect(run).not.toHaveBeenCalled();
  });
  it('cancels active and queued obsolete reads while retaining the new generation', async () => {
    const scheduler=new RequestScheduler(); const old=scheduler.enqueue(context('old'),false,'old',signal=>new Promise((_,reject)=>signal.addEventListener('abort',()=>reject(new Error('aborted')))));
    const rejected=expect(old).rejects.toThrow('aborted'); await Promise.resolve();
    const stale=scheduler.enqueue(context('stale'),false,'stale',async()=>1); const staleRejected=expect(stale).rejects.toThrow('cancelled');
    const current=scheduler.enqueue(context('new',1,2),false,'new',async()=>2);
    scheduler.cancel(undefined,false,2); await Promise.all([rejected,staleRejected]); expect(await current).toBe(2);
  });
  it('never aborts or replays a write already sent when backgrounding', async () => {
    const scheduler=new RequestScheduler(); let release!:()=>void; let aborted=false; let calls=0;
    const write=scheduler.enqueue(context('write',0),true,'write',async(signal,sent)=>{calls++;sent();signal.addEventListener('abort',()=>{aborted=true;});await new Promise<void>(resolve=>{release=resolve;});return 1;});
    await Promise.resolve(); scheduler.cancel(undefined,true); release(); expect(await write).toBe(1);expect(aborted).toBe(false);expect(calls).toBe(1);
  });
  it('drops an unsent queued write during backgrounding', async () => {
    const scheduler=new RequestScheduler();const run=vi.fn(async()=>1); const write=scheduler.enqueue(context('write'),true,'write',run);
    const rejected=expect(write).rejects.toThrow('cancelled');scheduler.cancel(undefined,true);await rejected;expect(run).not.toHaveBeenCalled();
  });
});
