/** Extra rows are bounded regardless of swipe velocity or total feed length. */
export function feedWindow(start: number, end: number, count: number, up: boolean, pixelsPerMs: number): number[] {
  const lead = pixelsPerMs > 2 ? 12 : 6;
  const trail = pixelsPerMs > 2 ? 4 : 3;
  const first = Math.max(0, start - (up ? lead : trail));
  const last = Math.min(count - 1, end + (up ? trail : lead));
  return Array.from({ length: Math.max(0, last - first + 1) }, (_, i) => first + i);
}
