import { describe, expect, it } from 'vitest';
import { feedWindow } from './feedWindow';
describe('feed window', () => {
  it('keeps every visible row after a large jump while bounding the runway', () => {
    const rows = feedWindow(700, 708, 10000, false, 30);
    expect(rows).toHaveLength(25);
    for (let i = 700; i <= 708; i++) expect(rows).toContain(i);
    expect(rows[0]).toBe(696); expect(rows.at(-1)).toBe(720);
  });
  it('changes the runway with direction and clamps both collection edges', () => {
    expect(feedWindow(10, 14, 100, true, 3)[0]).toBe(0);
    expect(feedWindow(98, 99, 100, false, 3).at(-1)).toBe(99);
    expect(feedWindow(0, 0, 0, false, 0)).toEqual([]);
  });
});
