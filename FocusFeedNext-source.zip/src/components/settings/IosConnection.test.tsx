import { beforeEach, describe, expect, it, vi } from 'vitest';
import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { IosWelcome } from './IosConnection';
import { api } from '@/lib/api';
import { renderWithProviders } from '@/test/factories';
describe('native iPhone sign-in', () => {
  beforeEach(() => vi.restoreAllMocks());
  it('requests native sign-in without asking for password or cookie fields', async () => {
    vi.spyOn(api, 'sessionStatus').mockResolvedValue({ hasCredentials: false, checking: false } as Awaited<ReturnType<typeof api.sessionStatus>>);
    const signIn = vi.spyOn(api, 'signInIos').mockRejectedValue(new Error('Sign-in was cancelled.'));
    renderWithProviders(<IosWelcome />);
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'Sign in with Twitter' }));
    expect(signIn).toHaveBeenCalledExactlyOnceWith();
    expect(await screen.findByRole('alert')).toHaveTextContent('Sign-in was cancelled.');
    expect(screen.getByRole('button', { name: 'Sign in with Twitter' })).toBeEnabled();
  });
  it('localizes a bootstrap failure and exposes its safe stage and retry action',async()=>{
    vi.spyOn(api,'sessionStatus').mockResolvedValue({hasCredentials:false,checking:false} as Awaited<ReturnType<typeof api.sessionStatus>>);
    vi.spyOn(api,'signInIos').mockRejectedValue({code:'schema_changed',message:'safe fallback',nativeConnectionFault:{code:'transaction_bootstrap',stage:'bootstrap',requestId:'12',retryable:true}});
    renderWithProviders(<IosWelcome/>);
    await userEvent.click(screen.getByRole('button',{name:'Sign in with Twitter'}));
    expect(await screen.findByRole('alert')).toHaveTextContent('connection metadata could not be read');
    expect(screen.getByRole('alert')).toHaveTextContent('Request 12');
    expect(screen.getByRole('button',{name:'Retry sign-in'})).toBeEnabled();
  });
});
