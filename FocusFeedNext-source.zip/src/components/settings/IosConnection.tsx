import { useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowRight, LoaderCircle, LogOut, ShieldCheck, SlidersHorizontal, Sparkles } from 'lucide-react';
import { api, isTauri, toAppError, type SessionSnapshot } from '@/lib/api';
import { useI18n } from '@/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardBody, CardHeader } from '@/components/ui/card';
import { resetFeedSessionState } from '@/hooks/useFeed';
import { acceptConnectedSession, acceptSessionSnapshot } from '@/hooks/useStartupSequence';
import { useAccountActionStore } from '@/components/account/accountActions';
import { useAppStore } from '@/stores/useAppStore';

function useIosAccount() {
  const qc = useQueryClient();
  const session = useQuery({ queryKey: ['sessionStatus'], queryFn: api.sessionStatus });
  const accept = (snapshot: SessionSnapshot) => {
    resetFeedSessionState();
    void qc.resetQueries({ predicate: q => q.queryKey[0] !== 'sessionStatus' });
    useAccountActionStore.getState().reset();
    if (snapshot.account) acceptConnectedSession(snapshot);
    else acceptSessionSnapshot(snapshot);
    qc.setQueryData(['sessionStatus'], snapshot);
  };
  const signIn = useMutation({ mutationFn: () => api.signInIos(), onSuccess: accept });
  const signOut = useMutation({ mutationFn: () => api.disconnect(), onSuccess: accept });
  return { session: session.data, signIn, signOut };
}

export function IosConnection() {
  const { t } = useI18n();
  const { session, signIn, signOut } = useIosAccount();
  const busy = signIn.isPending || signOut.isPending;
  const error = signIn.error ?? signOut.error;
  return <Card>
    <CardHeader title={t('ios.account.title')} icon={<ShieldCheck className="size-4" />} />
    <CardBody className="space-y-4">
      <p className="text-sm text-ink-dim">{t('ios.account.description')}</p>
      {session?.account ? <div className="flex items-center gap-3">
        {session.account.avatarUrl && <img src={session.account.avatarUrl} alt="" className="size-12 rounded-full" width={48} height={48} />}
        <div><p className="font-semibold">{session.account.displayName}</p><p className="text-sm text-ink-mute" dir="ltr">@{session.account.username}</p></div>
      </div> : null}
      <div className="flex flex-wrap gap-2">
        <Button variant="primary" disabled={busy} onClick={() => signIn.mutate()}>
          {signIn.isPending ? <LoaderCircle className="animate-spin" /> : <ArrowRight />}
          {t(session?.account ? 'ios.account.switch' : 'ios.signin')}
        </Button>
        {session?.hasCredentials && <Button variant="secondary" disabled={busy} onClick={() => signOut.mutate()}><LogOut />{t('ios.signout')}</Button>}
      </div>
      {error && <p role="alert" className="text-sm text-bad">{toAppError(error).message}</p>}
      <p className="text-xs leading-relaxed text-ink-mute">{t('ios.account.privacy')}</p>
    </CardBody>
  </Card>;
}

export function IosWelcome() {
  const { t } = useI18n();
  const { session, signIn } = useIosAccount();
  const setRoute = useAppStore(s => s.setRoute);
  useEffect(() => {
    if (isTauri()) void api.configureIosChrome(['','','','',''], 'following', true, false).catch(() => {});
  }, []);
  return <section className="ios-welcome">
    <div className="ios-welcome-orbit" aria-hidden="true"><Sparkles className="size-9" /></div>
    <div className="ios-eyebrow">{t('ios.welcome.eyebrow')}</div>
    <h1>{t('ios.welcome.title')}</h1>
    <p className="ios-welcome-description">{t('ios.welcome.description')}</p>
    <div className="ios-welcome-actions">
      <Button variant="primary" className="w-full min-h-14 rounded-2xl text-base" disabled={signIn.isPending || session?.checking} onClick={() => signIn.mutate()}>
        {signIn.isPending ? <LoaderCircle className="animate-spin" /> : <ArrowRight />}
        {t(signIn.isPending ? 'ios.signingIn' : 'ios.signin')}
      </Button>
      <Button variant="ghost" className="w-full min-h-12" onClick={() => setRoute('settings')}><SlidersHorizontal />{t('nav.settings')}</Button>
      {signIn.error && <p role="alert" className="text-sm text-bad">{toAppError(signIn.error).message}</p>}
    </div>
    <div className="ios-welcome-privacy"><ShieldCheck className="size-4 shrink-0" /><p>{t('ios.account.privacy')}</p></div>
  </section>;
}
