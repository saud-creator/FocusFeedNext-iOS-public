from http.server import BaseHTTPRequestHandler, HTTPServer
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self):
        paths = {
            '/': ('text/html', b'<html><head><link rel="stylesheet" href="/page.css"><script src="/page.js"></script></head><body><img id="image" src="/pixel.svg"></body></html>'),
            '/page.js': ('application/javascript', b'globalThis.pageScriptRan=true;'),
            '/page.css': ('text/css', b'body { color:rgb(1,2,3); }'),
            '/pixel.svg': ('image/svg+xml', b'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>'),
            '/explicit-fetch': ('text/plain', b'explicit-fetch-ok'),
        }
        content_type, content = paths.get(self.path, ('text/plain', b''))
        self.send_response(200); self.send_header('Content-Type',content_type); self.send_header('Content-Length',str(len(content))); self.end_headers(); self.wfile.write(content)
HTTPServer(('127.0.0.1',8769),Handler).serve_forever()
