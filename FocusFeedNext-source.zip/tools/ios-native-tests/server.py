from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import json, base64

frame = '<g><path/><path d="M0000000010 20 30 40 50 60 70 80 90 100 110' + 'C10 20 30 40 50 60 70 80 90 100 110' * 15 + '"/></g>'
engine_home = '<html><head><meta name="twitter-site-verification" content="' + base64.b64encode(bytes(32)).decode() + '"><script src="https://abs.twimg.com/responsive-web/client-web/ondemand.s.fixturehasha.js"></script><script>globalThis.pageScriptRan=true</script></head><body>' + ''.join('<svg id="loading-x-anim-'+str(i)+'">'+frame+'</svg>' for i in range(4)) + '</body></html>'
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self):
        parsed = urlparse(self.path)
        paths = {
            '/': ('text/html', b'<html><head><link rel="stylesheet" href="/page.css"><script src="/page.js"></script></head><body><img id="image" src="/pixel.svg"></body></html>'),
            '/page.js': ('application/javascript', b'globalThis.pageScriptRan=true;'),
            '/page.css': ('text/css', b'body { color:rgb(1,2,3); }'),
            '/pixel.svg': ('image/svg+xml', b'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>'),
            '/explicit-fetch': ('text/plain', b'explicit-fetch-ok'),
            '/engine-home': ('text/html', engine_home.encode()),
            '/engine-demand': ('text/plain', b'(keyBytes[0],16)(keyBytes[1],16)'),
            '/engine-me': ('application/json', b'{"users":[{"user_id":"42","screen_name":"fixture"}]}'),
            '/engine-profile': ('application/json', b'{"data":{"user":{"result":{"rest_id":"42","core":{"screen_name":"fixture","name":"Fixture"},"legacy":{"following":true}}}}}'),
        }
        status = 200
        if parsed.path in ['/engine-me', '/engine-profile']:
            valid = 'auth_token=fixture-only' in self.headers.get('Cookie','') and self.headers.get('x-csrf-token') == 'fixture-csrf' and 'ct0=fixture-csrf' in self.headers.get('Cookie','')
            if parsed.path == '/engine-profile':
                features = json.loads(parse_qs(parsed.query).get('features',['{}'])[0])
                valid = valid and features.get('subscriptions_verification_info_verified_since_enabled') is True and len(self.headers.get('x-client-transaction-id','')) > 20
            if not valid: status = 401
        content_type, content = paths.get(parsed.path, ('text/plain', b''))
        if status != 200: content = b'{"errors":[{"code":89}]}'
        self.send_response(status); self.send_header('Content-Type',content_type); self.send_header('Content-Length',str(len(content))); self.end_headers(); self.wfile.write(content)
HTTPServer(('127.0.0.1',8769),Handler).serve_forever()
