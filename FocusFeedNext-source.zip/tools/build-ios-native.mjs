import { build } from 'vite';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
await build({
  configFile: false,
  root,
  logLevel: 'warn',
  build: {
    outDir: 'src-tauri/plugins/ios-reader/ios/Sources',
    emptyOutDir: false,
    minify: true,
    lib: {
      entry: 'src-tauri/plugins/ios-reader/transaction/reader.ts',
      name: 'FfnReader',
      formats: ['iife'],
      fileName: () => 'Reader.js',
    },
  },
});
