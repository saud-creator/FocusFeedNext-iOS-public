// Request shapes and feature flags adapted from public-clis/twitter-cli (Apache-2.0).
// Transaction engine: Lqm1/x-client-transaction-id (MIT), vendored beside this file.
import ClientTransaction from './transaction';
import { RequestScheduler, type RequestContext } from './scheduler';

const queryIds: Record<string, string> = {
  HomeTimeline: 'c-CzHF1LboFilMpsx4ZCrQ', HomeLatestTimeline: 'BKB7oi212Fi7kQtCBGE4zA',
  UserByScreenName: '1VOOyvKkiI3FMmkeDNxM9A', UserTweets: 'q6xj5bs0hapm9309hexA_g',
  Bookmarks: '2neUNDqrrFzbLui8yallcQ', ListLatestTweetsTimeline: 'RlZzktZY_9wJynoepm8ZsA',
  Following: 'zx6e-TLzRkeDO_a7p4b3JQ', DeleteBookmark: 'Wlmlj2-xzyS1GN3a6cj-mQ',
};
const features: Record<string, boolean> = {
  responsive_web_graphql_exclude_directive_enabled: true, verified_phone_label_enabled: false,
  creator_subscriptions_tweet_preview_api_enabled: true, responsive_web_graphql_timeline_navigation_enabled: true,
  responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
  c9s_tweet_anatomy_moderator_badge_enabled: true, tweetypie_unmention_optimization_enabled: true,
  responsive_web_edit_tweet_api_enabled: true, graphql_is_translatable_rweb_tweet_is_translatable_enabled: true,
  view_counts_everywhere_api_enabled: true, longform_notetweets_consumption_enabled: true,
  responsive_web_twitter_article_tweet_consumption_enabled: true, tweet_awards_web_tipping_enabled: false,
  longform_notetweets_rich_text_read_enabled: true, longform_notetweets_inline_media_enabled: true,
  rweb_video_timestamps_enabled: true, responsive_web_media_download_video_enabled: true,
  freedom_of_speech_not_reach_fetch_enabled: true, standardized_nudges_misinfo: true,
  responsive_web_enhance_cards_enabled: false,
};
// Public web-client application identifier, not a user credential.
const bearer = 'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';
let transaction: ClientTransaction | null = null;
let initializedAt = 0;
let initialization: Promise<void> | null = null;
let nextRequestAt = 0;
let rateLimitedUntil = 0;

async function boundedFetch(url: string, init: RequestInit = {}) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  init.signal?.addEventListener('abort', abort, { once: true });
  if (init.signal?.aborted) controller.abort();
  const timeout = setTimeout(() => controller.abort(), 18000);
  try {
    const response = await fetch(url, { ...init, credentials: 'include', signal: controller.signal });
    // Keep the timeout active through body consumption, not only response headers.
    const body = await response.text();
    return new Response(body || null, { status: response.status, headers: response.headers });
  }
  finally { clearTimeout(timeout); init.signal?.removeEventListener('abort', abort); }
}
async function initialize(force = false, signal?: AbortSignal) {
  if (!force && transaction && Date.now() - initializedAt < 3600000) return;
  if (initialization) return initialization;
  initialization = (async () => {
    const response = await boundedFetch('https://x.com/home', { signal });
    if (!response.ok) throw new Error('Twitter connection initialization failed.');
    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    transaction = await ClientTransaction.create(doc, signal);
    // Only data is parsed. No downloaded script is evaluated or installed.
    for (const match of html.matchAll(/"([a-z][a-z0-9_]+)":\s*\{\s*"value"\s*:\s*(true|false)/g)) {
      if (match[1] in features) features[match[1]] = match[2] === 'true';
    }
    initializedAt = Date.now();
  })().finally(() => { initialization = null; });
  return initialization;
}
async function refreshQueryIds(signal: AbortSignal) {
  const response = await boundedFetch('https://x.com/home', { signal });
  const html = await response.text();
  const urls = [...new Set([...html.matchAll(/(?:src|href)=["'](https:\/\/abs\.twimg\.com\/responsive-web\/client-web[^"']+\.js)["']/g)].map(m => m[1]))].slice(0, 3);
  await Promise.all(urls.map(async url => {
    const script = await (await boundedFetch(url, { signal })).text();
    for (const match of script.matchAll(/queryId:\s*"([A-Za-z0-9_-]+)"[^}]{0,200}operationName:\s*"([^"]+)"/g)) {
      if (match[2] in queryIds) queryIds[match[2]] = match[1];
    }
  }));
}

const queue = new RequestScheduler();
export function cancel(id?: string, all = false, beforeGeneration = Infinity) { queue.cancel(id, all, beforeGeneration); }
export function request(operation: string, variables: Record<string, unknown>, csrf: string, context: RequestContext) {
  const write = ['Follow', 'Unfollow', 'DeleteBookmark'].includes(operation);
  const key = JSON.stringify([operation, Object.entries(variables).sort(([a],[b]) => a.localeCompare(b)), csrf]);
  return queue.enqueue(context, write, key, (signal,sent) => perform(operation, variables, csrf, signal,sent));
}
async function perform(operation: string, variables: Record<string, unknown>, csrf: string, signal: AbortSignal, sent: () => void) {
  if (!(operation in queryIds) && !['Me', 'Follow', 'Unfollow'].includes(operation)) throw new Error('Unsupported operation.');
  if (Date.now() < rateLimitedUntil) return { status: 429, body: {} };
  // Small pages are queued by Rust; a shared budget also covers all native callers.
  await new Promise(resolve => setTimeout(resolve, Math.max(0, nextRequestAt - Date.now())));
  signal.throwIfAborted();
  nextRequestAt = Date.now() + 700;
  await initialize(false, signal);
  signal.throwIfAborted();
  for (let attempt = 0; attempt < 2; attempt++) {
    const isRest = ['Me', 'Follow', 'Unfollow'].includes(operation);
    const write = ['Follow', 'Unfollow', 'DeleteBookmark'].includes(operation);
    const method = write || operation === 'Following' ? 'POST' : 'GET';
    const path = operation === 'Me' ? '/i/api/1.1/account/multi/list.json'
      : operation === 'Follow' ? '/i/api/1.1/friendships/create.json'
      : operation === 'Unfollow' ? '/i/api/1.1/friendships/destroy.json'
      : `/i/api/graphql/${queryIds[operation]}/${operation}`;
    const headers: Record<string, string> = {
      authorization: `Bearer ${bearer}`, 'x-csrf-token': csrf,
      'x-twitter-auth-type': 'OAuth2Session', 'x-twitter-active-user': 'yes',
      'x-twitter-client-language': 'en',
      'x-client-transaction-id': await transaction!.generateTransactionId(method, path),
    };
    let url = `https://x.com${path}`;
    let body: string | undefined;
    if (write && isRest) {
      headers['content-type'] = 'application/x-www-form-urlencoded';
      body = new URLSearchParams(variables as Record<string, string>).toString();
    } else if (method === 'POST') {
      headers['content-type'] = 'application/json';
      body = JSON.stringify({ variables, features, queryId: queryIds[operation] });
    } else if (!isRest) {
      url += '?' + new URLSearchParams({ variables: JSON.stringify(variables), features: JSON.stringify(features) });
    }
    signal.throwIfAborted();
    sent();
    const response = await boundedFetch(url, { method, headers, body, signal });
    if (response.status === 404 && attempt === 0 && !isRest && !write) {
      await refreshQueryIds(signal); continue;
    }
    let data: unknown = {};
    try { data = await response.json(); } catch { /* No raw HTML reaches diagnostics. */ }
    if (response.status === 429) {
      const reset = Number(response.headers.get('x-rate-limit-reset')) * 1000;
      rateLimitedUntil = Math.max(Date.now() + 60000, Number.isFinite(reset) ? reset : 0);
    }
    return { status: response.status, body: data };
  }
  throw new Error('Twitter changed this endpoint. Please reconnect or update the app.');
}
