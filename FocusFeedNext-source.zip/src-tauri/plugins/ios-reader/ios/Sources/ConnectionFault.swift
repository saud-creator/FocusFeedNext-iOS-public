import Foundation

enum ConnectionFault {
    static func value(_ code: String, _ stage: String, id: String? = nil, retryable: Bool = true, status: Int? = nil) -> [String: Any] {
        ["fault": ["code": code, "stage": stage, "requestId": id as Any? ?? NSNull(),
                   "retryable": retryable, "httpStatus": status as Any? ?? NSNull()]]
    }
    // Only our fixed messages enter this adapter. No exception descriptions are forwarded.
    static func fromMessage(_ message: String, id: String? = nil) -> [String: Any] {
        if message.contains("Keychain") || message.contains("storage") || message.contains("migrated") { return value("session_storage", "storage", id: id) }
        if message.contains("cancelled") || message.contains("no longer") || message.contains("background") { return value("cancelled", "queue", id: id, retryable: false) }
        if message.contains("too long") { return value("timeout", "provider", id: id) }
        if message.contains("unreadable") || message.contains("Unsupported") { return value("unsupported_response", "bridge", id: id, retryable: false) }
        if message.contains("transport") || message.contains("Transport") { return value("transport_initialization", "transport", id: id) }
        if message.contains("reached") { return value("network_failure", "provider", id: id) }
        return value("bridge_failure", "bridge", id: id)
    }
}
