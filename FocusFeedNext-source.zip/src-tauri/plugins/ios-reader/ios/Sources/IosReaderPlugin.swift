import Tauri
import UIKit
import WebKit
import Security

private struct RequestArgs: Decodable {
    let operation: String
    let variables: [String: AnyCodable]
    let authToken: String
    let ct0: String
}
// JSON values decoded without ever evaluating caller-provided JavaScript.
private struct AnyCodable: Decodable {
    let value: Any
    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { value = NSNull() }
        else if let v = try? c.decode(Bool.self) { value = v }
        else if let v = try? c.decode(Int.self) { value = v }
        else if let v = try? c.decode(Double.self) { value = v }
        else { value = try c.decode(String.self) }
    }
}
private struct ChromeArgs: Decodable {
    let labels: [String]
    let selected: String
    let dark: Bool
    let visible: Bool
}
// WebKit completion, navigation recovery and the deadline race on the main queue.
// Exactly one result reaches Rust even if WebKit completes after the deadline.
private final class RequestReply {
    private let invoke: Invoke
    private(set) var pending = true
    init(_ invoke: Invoke) {
        self.invoke = invoke
        DispatchQueue.main.asyncAfter(deadline: .now() + 75) { [weak self] in
            self?.reject("Twitter took too long to respond. Please try again.")
        }
    }
    func resolve(_ value: [String: Any]) {
        guard pending else { return }; pending = false; invoke.resolve(value)
    }
    func reject(_ message: String) {
        guard pending else { return }; pending = false; invoke.reject(message)
    }
}
private final class LoginController: UIViewController, UIAdaptivePresentationControllerDelegate {
    var cancel: (() -> Void)?
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isBeingDismissed || navigationController?.isBeingDismissed == true { cancel?() }
    }
}

class IosReaderPlugin: Plugin, WKNavigationDelegate, WKHTTPCookieStoreObserver {
    private weak var reader: WKWebView?
    private var browser: WKWebView!
    private var loginInvoke: Invoke?
    private var loginController: UINavigationController?
    private var pendingCookies: [HTTPCookie] = []
    private var chrome: UIVisualEffectView?
    private var chromeButtons: [UIButton] = []
    private var readyCallbacks: [() -> Void] = []
    private var loading = false
    private var activeToken = ""
    private let routes = ["following", "focus", "bookmarks", "accounts", "more"]
    private let world = WKContentWorld.world(name: "FocusFeedPrivateTransport")
    private let keychainAccount = "twitter-browser-cookies-v1"

    override func load(webview: WKWebView) {
        reader = webview
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        browser = WKWebView(frame: .zero, configuration: config)
        browser.navigationDelegate = self
        config.websiteDataStore.httpCookieStore.add(self)
        if #available(iOS 16.4, *) { browser.isInspectable = false }
    }

    @objc func login(_ invoke: Invoke) {
        DispatchQueue.main.async {
            guard self.loginInvoke == nil else { invoke.reject("Sign-in is already open."); return }
            guard let root = self.reader?.window?.rootViewController else { invoke.reject("The reader is not ready."); return }
            self.loginInvoke = invoke
            self.pendingCookies = []
            let page = LoginController()
            page.title = "Sign in to Twitter"
            page.view = self.browser
            page.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(self.cancelLogin))
            page.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Continue", style: .done, target: self, action: #selector(self.completeLogin))
            page.cancel = { [weak self] in self?.cancelLogin() }
            let nav = UINavigationController(rootViewController: page)
            nav.modalPresentationStyle = .fullScreen
            self.loginController = nav
            self.chrome?.isHidden = true
            root.present(nav, animated: true)
            self.browser.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) {
                self.browser.load(URLRequest(url: URL(string: "https://x.com/i/flow/login")!))
            }
        }
    }
    @objc private func cancelLogin() {
        guard let invoke = loginInvoke else { return }
        loginInvoke = nil
        loginController?.dismiss(animated: true)
        loginController = nil
        chrome?.isHidden = false
        invoke.reject("Sign-in was cancelled.")
    }
    @objc private func completeLogin() {
        guard let invoke = loginInvoke else { return }
        browser.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
            guard self.loginInvoke != nil else { return }
            let xCookies = cookies.filter { $0.domain == "x.com" || $0.domain == ".x.com" || $0.domain == "twitter.com" || $0.domain == ".twitter.com" }
            guard let token = xCookies.first(where: { $0.name == "auth_token" }),
                  let csrf = xCookies.first(where: { $0.name == "ct0" }) else { return }
            self.pendingCookies = xCookies
            self.activeToken = token.value
            self.loginInvoke = nil
            self.loginController?.dismiss(animated: true)
            self.loginController = nil
            self.chrome?.isHidden = false
            // Resolved only to Rust's plugin handle. The React command receives a SessionSnapshot.
            invoke.resolve(["authToken": token.value, "ct0": csrf.value])
        }
    }
    func cookiesDidChange(in cookieStore: WKHTTPCookieStore) {
        guard loginInvoke != nil, browser.url?.host == "x.com", browser.url?.path == "/home" else { return }
        completeLogin()
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        loading = false
        if loginInvoke != nil, webView.url?.path == "/home" { completeLogin() }
        let callbacks = readyCallbacks
        readyCallbacks.removeAll()
        callbacks.forEach { $0() }
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        loading = false
        let callbacks = readyCallbacks
        readyCallbacks.removeAll()
        callbacks.forEach { $0() }
        if loginInvoke != nil { cancelLogin() }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        loading = false
        let callbacks = readyCallbacks
        readyCallbacks.removeAll()
        callbacks.forEach { $0() }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url, url.scheme == "https", let host = url.host,
              host == "x.com" || host.hasSuffix(".x.com") || host == "twitter.com" || host.hasSuffix(".twitter.com") || host == "accounts.google.com" || host == "appleid.apple.com" else {
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }
    @objc func commit(_ invoke: Invoke) {
        DispatchQueue.main.async {
            let rows = self.pendingCookies.compactMap { cookie -> [String: Any]? in
                ["name": cookie.name, "value": cookie.value, "domain": cookie.domain, "path": cookie.path,
                 "secure": cookie.isSecure, "expires": cookie.expiresDate?.timeIntervalSince1970 ?? 0]
            }
            guard let data = try? JSONSerialization.data(withJSONObject: rows) else { invoke.reject("Session storage failed."); return }
            let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: "com.focusfeed.next.ios", kSecAttrAccount as String: self.keychainAccount]
            var update = query
            update[kSecValueData as String] = data
            update[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            let status = SecItemUpdate(query as CFDictionary, [kSecValueData as String: data] as CFDictionary)
            if status == errSecItemNotFound {
                guard SecItemAdd(update as CFDictionary, nil) == errSecSuccess else { invoke.reject("Keychain could not save the session."); return }
            } else if status != errSecSuccess { invoke.reject("Keychain could not save the session."); return }
            self.pendingCookies = []
            invoke.resolve()
        }
    }
    private func savedCookies() -> [HTTPCookie] {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.focusfeed.next.ios", kSecAttrAccount as String: keychainAccount,
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data,
              let rows = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
        return rows.compactMap { row in
            var p: [HTTPCookiePropertyKey: Any] = [.name: row["name"] ?? "", .value: row["value"] ?? "",
                .domain: row["domain"] ?? "x.com", .path: row["path"] ?? "/", .secure: "TRUE"]
            if let expiry = row["expires"] as? Double, expiry > 0 { p[.expires] = Date(timeIntervalSince1970: expiry) }
            return HTTPCookie(properties: p)
        }
    }
    @objc func logout(_ invoke: Invoke) {
        DispatchQueue.main.async {
            let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: "com.focusfeed.next.ios", kSecAttrAccount as String: self.keychainAccount]
            let status = SecItemDelete(query as CFDictionary)
            guard status == errSecSuccess || status == errSecItemNotFound else { invoke.reject("Keychain could not remove the session."); return }
            self.activeToken = ""
            self.pendingCookies = []
            self.browser.stopLoading()
            self.browser.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { invoke.resolve() }
        }
    }
    @objc func request(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(RequestArgs.self)
        let allowed = ["Me", "HomeTimeline", "HomeLatestTimeline", "Bookmarks", "UserByScreenName", "UserTweets", "Following", "ListLatestTweetsTimeline", "DeleteBookmark", "Follow", "Unfollow"]
        guard allowed.contains(args.operation), args.authToken.count <= 512, args.ct0.count <= 512 else { invoke.reject("Unsupported request."); return }
        DispatchQueue.main.async {
            let reply = RequestReply(invoke)
            let cookies = self.pendingCookies.isEmpty ? self.savedCookies() : self.pendingCookies
            let group = DispatchGroup()
            let store = self.browser.configuration.websiteDataStore.httpCookieStore
            let matching = cookies.filter { $0.name != "auth_token" && $0.name != "ct0" }
            let base = ["auth_token": args.authToken, "ct0": args.ct0].compactMap { name, value in
                HTTPCookie(properties: [.name: name, .value: value, .domain: ".x.com", .path: "/", .secure: "TRUE"])
            }
            for cookie in matching + base { group.enter(); store.setCookie(cookie) { group.leave() } }
            group.notify(queue: .main) {
                guard reply.pending else { return }
                let perform = { if reply.pending { self.performRequest(args, reply) } }
                if self.browser.url?.host == "x.com", !self.loading { perform() }
                else {
                    self.readyCallbacks.append(perform)
                    if !self.loading {
                        self.loading = true
                        self.browser.load(URLRequest(url: URL(string: "https://x.com/home")!))
                    }
                }
            }
        }
    }
    private func performRequest(_ args: RequestArgs, _ reply: RequestReply) {
        let script = NativeReaderScript.source
        let source = "if (!globalThis.__ffnReader) {" + script + ";globalThis.__ffnReader = FfnReader;}\nreturn await globalThis.__ffnReader.request(operation, variables, csrf);"
        browser.callAsyncJavaScript(source, arguments: ["operation": args.operation,
            "variables": args.variables.mapValues { $0.value }, "csrf": args.ct0], in: nil, in: world) { result in
            switch result {
            case .success(let value):
                guard let response = value as? [String: Any] else { reply.reject("Twitter returned an unreadable response."); return }
                reply.resolve(response)
            case .failure:
                reply.reject("Twitter could not be reached. Check your connection and sign in again if needed.")
            }
        }
    }
    @objc func configureChrome(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(ChromeArgs.self)
        DispatchQueue.main.async {
            guard args.labels.count == 5, let webview = self.reader, let parent = webview.superview else { invoke.reject("Reader chrome is not ready."); return }
            if self.chrome == nil {
                let effect: UIVisualEffect
                #if compiler(>=6.2)
                if #available(iOS 26.0, *), !UIAccessibility.isReduceTransparencyEnabled {
                    effect = UIGlassEffect(style: .regular)
                } else { effect = UIBlurEffect(style: .systemMaterial) }
                #else
                effect = UIBlurEffect(style: .systemMaterial)
                #endif
                let bar = UIVisualEffectView(effect: effect)
                bar.translatesAutoresizingMaskIntoConstraints = false
                bar.layer.cornerRadius = 30
                bar.clipsToBounds = true
                let stack = UIStackView()
                stack.translatesAutoresizingMaskIntoConstraints = false
                stack.distribution = .fillEqually
                let symbols = ["square.stack", "scope", "bookmark", "person.2", "ellipsis"]
                for index in 0..<5 {
                    let button = UIButton(type: .system)
                    button.tag = index
                    var config = UIButton.Configuration.plain()
                    config.image = UIImage(systemName: symbols[index])
                    config.imagePlacement = .top
                    config.imagePadding = 3
                    config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { value in
                        var out = value; out.font = .systemFont(ofSize: 10, weight: .medium); return out
                    }
                    button.configuration = config
                    button.addTarget(self, action: #selector(self.selectTab(_:)), for: .touchUpInside)
                    stack.addArrangedSubview(button)
                    self.chromeButtons.append(button)
                }
                bar.contentView.addSubview(stack)
                parent.addSubview(bar)
                NSLayoutConstraint.activate([
                    bar.leadingAnchor.constraint(equalTo: webview.leadingAnchor, constant: 12),
                    bar.trailingAnchor.constraint(equalTo: webview.trailingAnchor, constant: -12),
                    bar.bottomAnchor.constraint(equalTo: parent.safeAreaLayoutGuide.bottomAnchor, constant: -6),
                    bar.heightAnchor.constraint(equalToConstant: 64),
                    stack.leadingAnchor.constraint(equalTo: bar.contentView.leadingAnchor, constant: 5),
                    stack.trailingAnchor.constraint(equalTo: bar.contentView.trailingAnchor, constant: -5),
                    stack.topAnchor.constraint(equalTo: bar.contentView.topAnchor), stack.bottomAnchor.constraint(equalTo: bar.contentView.bottomAnchor)
                ])
                self.chrome = bar
            }
            self.chrome?.overrideUserInterfaceStyle = args.dark ? .dark : .light
            self.chrome?.isHidden = !args.visible
            self.chrome?.backgroundColor = UIAccessibility.isReduceTransparencyEnabled ? .secondarySystemBackground : .clear
            for (index, button) in self.chromeButtons.enumerated() {
                button.configuration?.title = args.labels[index]
                button.accessibilityLabel = args.labels[index]
                let selected = self.routes[index] == args.selected || (index == 4 && !self.routes.contains(args.selected))
                button.tintColor = selected ? .systemBlue : .secondaryLabel
                button.accessibilityTraits = selected ? [.button, .selected] : [.button]
            }
            invoke.resolve(["native": true])
        }
    }
    @objc private func selectTab(_ sender: UIButton) {
        guard routes.indices.contains(sender.tag) else { return }
        UISelectionFeedbackGenerator().selectionChanged()
        let route = routes[sender.tag]
        reader?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('ffn-native-route', {detail:'\(route)'}));")
    }
}
@_cdecl("init_plugin_ios_reader")
func initPlugin() -> Plugin { IosReaderPlugin() }
