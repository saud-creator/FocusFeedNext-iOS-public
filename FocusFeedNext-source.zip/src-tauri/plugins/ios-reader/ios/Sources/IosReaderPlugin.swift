import Tauri
import UIKit
import WebKit
import Security

private struct RequestArgs: Decodable {
    let operation: String
    let variables: [String: AnyCodable]
    let authToken: String
    let ct0: String
    let context: RequestContext
}
private struct RequestContext: Decodable { let id: String; let generation: UInt64; let priority: Int; let deadline: UInt64; let authentication: Bool? }
private struct LoginFailureArgs: Decodable { let code: String }
// JSON values decoded without ever evaluating caller-provided JavaScript.
private struct AnyCodable: Decodable {
    let value: Any
    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { value = NSNull() }
        else if let v = try? c.decode(Bool.self) { value = v }
        else if let v = try? c.decode(Int.self) { value = v }
        else if let v = try? c.decode(Double.self) { value = v }
        else { value = try c.decode(String.self) }
    }
}
private struct ChromeArgs: Decodable {
    let labels: [String]
    let accessibilityLabels: [String]?
    let selected: String
    let dark: Bool
    let visible: Bool
    let routes: [String]
    let accent: String
    let haptics: Bool
    let rtl: Bool
}
private struct ShareArgs: Decodable { let bundle: String }
private struct ProfileArgs: Decodable { let username: String }
private struct SessionArgs: Decodable { let authToken: String; let ct0: String }
private struct CancelArgs: Decodable { let beforeGeneration: UInt64? }
// WebKit completion, navigation recovery and the deadline race on the main queue.
// Exactly one result reaches Rust even if WebKit completes after the deadline.
private func rejectNative(_ invoke: Invoke, _ message: String) { invoke.resolve(ConnectionFault.fromMessage(message)) }

private final class RequestReply {
    private let invoke: Invoke
    private(set) var pending = true
    var expired: (() -> Void)?
    private let id: String?
    private let createdAt = Date()
    let authentication: Bool
    var elapsedMs: Double { min(75000, max(0, Date().timeIntervalSince(createdAt) * 1000)) }
    init(_ invoke: Invoke, deadline: UInt64, id: String? = nil, authentication: Bool = false) {
        self.invoke = invoke; self.id = id; self.authentication = authentication
        let seconds = min(75, max(0, Double(deadline) / 1000 - Date().timeIntervalSince1970))
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) { [weak self] in
            guard self?.pending == true else { return }
            self?.expired?()
            self?.reject("Twitter took too long to respond. Please try again.")
        }
    }
    func resolve(_ value: [String: Any]) {
        guard pending else { return }; pending = false; invoke.resolve(value)
    }
    func reject(_ message: String) {
        guard pending else { return }; pending = false; invoke.resolve(ConnectionFault.fromMessage(message, id: id))
    }
    func interruptAuthentication(_ code: String) {
        resolve(ConnectionFault.value(code, "identity", id: id, retryable: code == "background_paused"))
    }
}
private final class LoginController: UIViewController, UIAdaptivePresentationControllerDelegate {
    var cancel: (() -> Void)?
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isBeingDismissed || navigationController?.isBeingDismissed == true { cancel?() }
    }
}

class IosReaderPlugin: Plugin, WKNavigationDelegate, WKUIDelegate, WKHTTPCookieStoreObserver, UITabBarDelegate {
    private weak var reader: WKWebView?
    private var browser: WKWebView!
    private var loginBrowser: WKWebView?
    private var loginPopup: WKWebView?
    private var loginWaiting: [Invoke] = []
    private var loginNeedsReload = false
    private var deviceRuntime: DeviceRuntime?
    private var replies: [String: (RequestReply, Bool, UInt64)] = [:]
    private var issuedIds = Set<String>()
    private var transportReady = false
    private var ruleCompiling = false
    private var transportNavigation: WKNavigation?
    private var transportEpoch: UInt64 = 0
    private var needsReload = true
    private var nativeHaptics = true
    private let sessionTransaction = SessionTransaction()
    private var chromeHeight: NSLayoutConstraint?
    private var loginInvoke: Invoke?
    private var loginCompleting = false
    private var loginCommitted = false
    private var loginResume: (() -> Void)?
    private var loginToken: UUID?
    private var loginHandoff = LoginHandoff()
    private var loginController: UINavigationController?
    private var pendingCookies: [HTTPCookie] = []
    private var chrome: UIVisualEffectView?
    private var tabBar: UITabBar?
    private var readyCallbacks: [String: (UInt64, () -> Void)] = [:]
    private var loading = false
    private var activeToken = ""
    private var cookieJobs: [() -> Void] = []
    private var cookieBusy = false
    private var connectionTimings: [[String: Any]] = []
    private var routes = ["following", "focus", "bookmarks", "accounts", "more"]
    private let world = WKContentWorld.world(name: "FocusFeedPrivateTransport")
    private let keychainAccount = "twitter-browser-cookies-v1"

    override func load(webview: WKWebView) {
        reader = webview
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        browser = WKWebView(frame: .zero, configuration: config)
        // Keep WebKit attached to the app's active hierarchy without exposing
        // the transport document to touch or accessibility navigation.
        browser.frame = CGRect(x:-2,y:-2,width:1,height:1)
        browser.isUserInteractionEnabled = false
        browser.accessibilityElementsHidden = true
        webview.addSubview(browser)
        browser.navigationDelegate = self
        compileTransportRules()
        deviceRuntime = DeviceRuntime()
        deviceRuntime?.changed = { [weak self] snapshot in
            guard let self = self else { return }
            if snapshot["foreground"] as? Bool == false { self.cancelTransportReads(all:true) }
            if snapshot["active"] as? Bool == true {
                if self.loginNeedsReload && !self.loginCompleting { self.loginNeedsReload = false; (self.loginPopup ?? self.loginBrowser)?.reload() }
                if let resume = self.loginResume { self.loginResume = nil; resume() }
                let waiting = self.loginWaiting; self.loginWaiting.removeAll()
                waiting.forEach { $0.resolve() }
                if !self.loginCompleting { self.completeLogin() }
            }
            if let data = try? JSONSerialization.data(withJSONObject: snapshot), let json = String(data: data, encoding: .utf8) {
                self.reader?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('ffn-runtime', {detail:\(json)}));")
            }
            self.refreshGlass()
        }
        if #available(iOS 16.4, *) { browser.isInspectable = false }
    }

    private func compileTransportRules(attempt: Int = 0) {
        guard !ruleCompiling, !transportReady else { return }
        ruleCompiling = true
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "ffn-transport-v2", encodedContentRuleList: TransportRules.encoded) { [weak self] list, _ in
            guard let self = self else { return }
            self.ruleCompiling = false
            if let list = list {
                self.browser.configuration.userContentController.add(list)
                self.transportReady = true
            } else if attempt == 0 {
                self.compileTransportRules(attempt: 1); return
            }
            // Blocking rules are defense in depth. Our empty, app-owned document
            // and navigation policy do not depend on their compilation to log in.
        }
    }
    private func emitStage(_ stage: String) {
        guard let data = try? JSONSerialization.data(withJSONObject: stage, options: .fragmentsAllowed), let json = String(data: data, encoding: .utf8) else { return }
        reader?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('ffn-connection-stage', {detail:\(json)}));")
    }
    @objc func login(_ invoke: Invoke) {
        DispatchQueue.main.async {
            guard self.loginToken == nil else { rejectNative(invoke, "Sign-in is already open."); return }
            guard let root = self.reader?.window?.rootViewController else { rejectNative(invoke, "The reader is not ready."); return }
            self.emitStage("login")
            self.loginInvoke = invoke
            self.loginCompleting = false
            self.loginCommitted = false
            self.loginHandoff = LoginHandoff()
            self.loginResume = nil
            let attempt = UUID(); self.loginToken = attempt
            DispatchQueue.main.asyncAfter(deadline: .now() + 600) { [weak self] in
                guard let self = self, self.loginToken == attempt, !self.loginCommitted else { return }
                self.finishLoginFailure(self.loginInvoke, code: "timeout")
            }
            self.pendingCookies = []
            self.cancelTransportReads()
            self.activeToken = ""
            let config = WKWebViewConfiguration()
            config.websiteDataStore = .nonPersistent()
            let login = WKWebView(frame: .zero, configuration: config)
            login.navigationDelegate = self
            login.uiDelegate = self
            config.websiteDataStore.httpCookieStore.add(self)
            if #available(iOS 16.4, *) { login.isInspectable = false }
            self.loginBrowser = login
            let page = LoginController()
            let arabic = Locale.preferredLanguages.first?.hasPrefix("ar") == true
            page.title = arabic ? "تسجيل الدخول إلى تويتر" : "Sign in to Twitter"
            page.view = login
            page.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(self.cancelLogin))
            page.navigationItem.rightBarButtonItem = UIBarButtonItem(title: arabic ? "متابعة" : "Continue", style: .done, target: self, action: #selector(self.continueLogin))
            page.cancel = { [weak self] in if self?.loginCompleting == false { self?.cancelLogin() } }
            let nav = UINavigationController(rootViewController: page)
            nav.modalPresentationStyle = .fullScreen
            self.loginController = nav
            self.chrome?.isHidden = true
            root.present(nav, animated: true)
            login.load(URLRequest(url: URL(string: "https://x.com/i/flow/login")!))
        }
    }
    @objc private func cancelLogin() {
        guard loginToken != nil, !loginCommitted else { return }
        finishLoginFailure(loginInvoke, code: "cancelled")
    }
    private func finishLoginFailure(_ invoke: Invoke?, code: String) {
        loginHandoff.cancel()
        loginInvoke = nil; loginToken = nil; loginResume = nil; loginCompleting = false
        loginCommitted = false
        let waiting = loginWaiting; loginWaiting.removeAll()
        waiting.forEach { $0.resolve(ConnectionFault.value(code,"login",retryable:code != "cancelled")) }
        cancelTransportReads(all: true, authenticationFault: code)
        loginBrowser?.configuration.websiteDataStore.httpCookieStore.remove(self)
        loginPopup?.stopLoading(); loginPopup = nil
        loginBrowser?.stopLoading(); loginBrowser = nil
        loginController?.dismiss(animated: true); loginController = nil
        loginNeedsReload = false; pendingCookies = []; activeToken = ""; needsReload = true; loading = false; browser.stopLoading(); chrome?.isHidden = false
        invoke?.resolve(ConnectionFault.value(code, "login", retryable: code != "cancelled"))
    }
    @objc func waitForLoginActive(_ invoke: Invoke) { DispatchQueue.main.async {
        guard self.loginToken != nil, self.loginCompleting else { invoke.resolve(ConnectionFault.value("cancelled","login",retryable:false)); return }
        if UIApplication.shared.applicationState == .active { invoke.resolve() }
        else { self.loginWaiting.append(invoke) }
    } }
    @objc func endLogin(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(LoginFailureArgs.self)
        DispatchQueue.main.async {
            guard let controller = self.loginController, controller.presentedViewController == nil, args.code != "cancelled", UIApplication.shared.applicationState == .active else {
                self.finishLoginFailure(nil,code:args.code); invoke.resolve(); return
            }
            let arabic = Locale.preferredLanguages.first?.hasPrefix("ar") == true
            let alert = UIAlertController(title:arabic ? "تعذر إكمال الاتصال" : "Connection could not complete",message:ConnectionFault.loginMessage(args.code,arabic:arabic),preferredStyle:.alert)
            alert.addAction(UIAlertAction(title:arabic ? "حسنًا" : "OK",style:.default) { _ in
                self.finishLoginFailure(nil,code:args.code)
            })
            controller.present(alert,animated:true); invoke.resolve()
        }
    }
    @objc private func continueLogin() { completeLogin(showMissing: true) }
    private func completeLogin(showMissing: Bool = false) {
        guard let invoke = loginInvoke, let login = loginBrowser, let attempt = loginToken, !loginCompleting,
              showMissing || LoginNavigation.isHome(login.url) || LoginNavigation.isHome(loginPopup?.url) else { return }
        loginCompleting = true
        let handoff = loginHandoff
        login.configuration.websiteDataStore.httpCookieStore.getAllCookies { [weak self] cookies in
            guard let self = self, self.loginInvoke != nil, self.loginToken == attempt else { return }
            guard let selection = LoginCookies.select(cookies) else {
                self.loginCompleting = false
                if showMissing {
                    let arabic = Locale.preferredLanguages.first?.hasPrefix("ar") == true
                    let alert = UIAlertController(title: arabic ? "أكمل تسجيل الدخول" : "Finish signing in", message: arabic ? "أكمل تسجيل الدخول في تويتر ثم اضغط متابعة." : "Complete Twitter sign-in, then tap Continue.", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: arabic ? "حسنًا" : "OK", style: .default))
                    self.loginController?.present(alert, animated: true)
                }
                return
            }
            self.emitStage("cookies")
            self.pendingCookies = selection.cookies
            login.configuration.websiteDataStore.httpCookieStore.remove(self)
            login.isUserInteractionEnabled = false; self.loginPopup?.isUserInteractionEnabled = false
            handoff.didCapture()
            let arabic = Locale.preferredLanguages.first?.hasPrefix("ar") == true
            self.loginController?.topViewController?.title = arabic ? "جارٍ التحقق من الاتصال…" : "Verifying connection…"
            self.loginController?.topViewController?.navigationItem.rightBarButtonItem?.isEnabled = false
            let publish = { [weak self] in
                    guard let self = self else { return }
                    guard self.loginInvoke != nil, self.loginToken == attempt else { return }
                    guard handoff.finish(active: UIApplication.shared.applicationState == .active) else { return }
                    self.loginInvoke = nil
                    invoke.resolve(["authToken": selection.token, "ct0": selection.csrf])
            }
            if UIApplication.shared.applicationState == .active { publish() }
            else { self.loginResume = publish }
        }
    }
    func cookiesDidChange(in cookieStore: WKHTTPCookieStore) {
        guard loginInvoke != nil else { return }
        completeLogin()
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if webView === loginBrowser || webView === loginPopup { if LoginNavigation.isHome(webView.url) { completeLogin() }; return }
        guard webView === browser, navigation === transportNavigation else { return }
        let epoch = transportEpoch
        webView.evaluateJavaScript(TransportDocument.originCheck, in: nil, in: world) { [weak self] value, error in
            guard let self = self, epoch == self.transportEpoch else { return }
            guard error == nil, value as? Bool == true else { self.failTransport(stage: "transport_origin"); return }
            self.loading = false; self.needsReload = false
            let callbacks = self.readyCallbacks; self.readyCallbacks.removeAll()
            callbacks.values.forEach { $0.1() }
        }
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if webView === loginBrowser || webView === loginPopup {
            if !loginCompleting {
                loginNeedsReload = true
                if UIApplication.shared.applicationState == .active { loginNeedsReload = false; webView.reload() }
            }
            return
        }
        failTransport(stage: "transport_process")
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if LoginNavigation.ignore(error,captured:false) { return }
        if webView === loginBrowser || webView === loginPopup {
            if LoginNavigation.ignore(error,captured:loginCompleting) { return }
            if LoginNavigation.recoverOnReturn(error,captured:loginCompleting,active:UIApplication.shared.applicationState == .active) { loginNeedsReload = true; return }
            if let invoke = loginInvoke { finishLoginFailure(invoke, code: "network_failure") }; return
        }
        if navigation === transportNavigation { failTransport(stage: "transport_navigation", error: error) }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if LoginNavigation.ignore(error,captured:false) { return }
        if webView === loginBrowser || webView === loginPopup {
            if LoginNavigation.ignore(error,captured:loginCompleting) { return }
            if LoginNavigation.recoverOnReturn(error,captured:loginCompleting,active:UIApplication.shared.applicationState == .active) { loginNeedsReload = true; return }
            if let invoke = loginInvoke { finishLoginFailure(invoke, code: "network_failure") }
        }
        else if navigation === transportNavigation { failTransport(stage: "transport_navigation", error: error) }
    }
    private func failTransport(stage: String, error: Error? = nil) {
        loading = false
        needsReload = true
        transportEpoch &+= 1; transportNavigation = nil
        readyCallbacks.removeAll()
        for (id, (reply, _, _)) in replies { reply.resolve(ConnectionFault.transport(stage: stage, id: id, error: error)) }
        replies.removeAll()
        issuedIds.removeAll()
        browser.stopLoading()
    }
    @objc func runtime(_ invoke: Invoke) {
        DispatchQueue.main.async {
            let snapshot: [String: Any] = self.deviceRuntime?.snapshot() ?? [:]
            invoke.resolve(snapshot)
        }
    }
    @objc func connectionMetrics(_ invoke: Invoke) {
        DispatchQueue.main.async { invoke.resolve(["samples": self.connectionTimings]) }
    }
    @objc func openProfile(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(ProfileArgs.self)
        guard !args.username.isEmpty, args.username.count <= 15, args.username.utf8.allSatisfy({ ($0 >= 65 && $0 <= 90) || ($0 >= 97 && $0 <= 122) || ($0 >= 48 && $0 <= 57) || $0 == 95 }), let url = URL(string: "https://x.com/\(args.username)") else { rejectNative(invoke,"Unsupported request."); return }
        DispatchQueue.main.async {
            UIApplication.shared.open(url, options: [:]) { opened in
                if opened { invoke.resolve() } else { rejectNative(invoke,"The creator profile could not open.") }
            }
        }
    }
    @objc func sharePreferences(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(ShareArgs.self)
        DispatchQueue.main.async {
            guard let root = self.reader?.window?.rootViewController,
                  let data = args.bundle.data(using:.utf8),data.count <= 32768 else { rejectNative(invoke, "Preferences could not be exported."); return }
            let file = FileManager.default.temporaryDirectory.appendingPathComponent("FocusFeedNext-preferences-\(UUID().uuidString).json")
            do { try data.write(to:file,options:.atomic) } catch { rejectNative(invoke, "Preferences could not be exported."); return }
            let sheet = UIActivityViewController(activityItems:[file],applicationActivities:nil)
            sheet.popoverPresentationController?.sourceView = root.view
            sheet.popoverPresentationController?.sourceRect = CGRect(x:root.view.bounds.midX,y:root.view.bounds.midY,width:1,height:1)
            sheet.completionWithItemsHandler = { _,_,_,_ in try? FileManager.default.removeItem(at:file); invoke.resolve() }
            root.present(sheet,animated:true)
        }
    }
    @objc func cancelReads(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(CancelArgs.self)
        DispatchQueue.main.async { self.cancelTransportReads(beforeGeneration:args.beforeGeneration); invoke.resolve() }
    }
    private func cancelTransportReads(beforeGeneration: UInt64? = nil, all: Bool = false, authenticationFault: String = "background_paused") {
        var obsoleteIds: [String] = []
        for (id, (reply, write, generation)) in replies where (!write || (all && !issuedIds.contains(id))) && (all || !reply.authentication) && (beforeGeneration == nil || generation < beforeGeneration!) {
            obsoleteIds.append(id)
            if reply.authentication { reply.interruptAuthentication(authenticationFault) }
            else { reply.reject("Request no longer needed.") }
            replies.removeValue(forKey:id); issuedIds.remove(id); readyCallbacks.removeValue(forKey:id)
        }
        // WebKit can defer this script until activation. Scope cancellation to
        // the captured IDs so it cannot abort a newly resumed identity check.
        if !obsoleteIds.isEmpty {
            browser.callAsyncJavaScript("for (const id of ids) globalThis.__ffnReader?.cancel(id);",arguments:["ids":obsoleteIds],in:nil,in:world) { _ in }
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if webView === browser {
            decisionHandler(TransportDocument.permitsNavigation(navigationAction.request.url, bootstrapping: loading) ? .allow : .cancel)
            return
        }
        if (webView === loginBrowser || webView === loginPopup), navigationAction.request.url?.host == "accounts.google.com" {
            let arabic = Locale.preferredLanguages.first?.hasPrefix("ar") == true
            if loginController?.presentedViewController == nil {
                let alert = UIAlertController(title:arabic ? "استخدم البريد الإلكتروني أو اسم المستخدم" : "Use email or username",message:arabic ? "Google لا يدعم تسجيل الدخول داخل متصفح iOS المضمّن. سجّل الدخول إلى X باستخدام بريدك الإلكتروني أو اسم المستخدم وكلمة مرور X." : "Google does not support sign-in inside embedded iOS browsers. Sign in to X with your email or username and your X password.",preferredStyle:.alert)
                alert.addAction(UIAlertAction(title:arabic ? "حسنًا" : "OK",style:.default)); loginController?.present(alert,animated:true)
            }
            decisionHandler(.cancel); return
        }
        guard let url = navigationAction.request.url, url.scheme == "https", let host = url.host,
              host == "x.com" || host.hasSuffix(".x.com") || host == "twitter.com" || host.hasSuffix(".twitter.com") || host == "appleid.apple.com" || host == "idmsa.apple.com" || host == "account.apple.com" else {
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard webView === loginBrowser, loginPopup == nil, navigationAction.targetFrame == nil,
              let url = navigationAction.request.url, url.scheme == "https", url.host != "accounts.google.com" else { return nil }
        let popup = WKWebView(frame:.zero,configuration:configuration)
        popup.navigationDelegate = self; popup.uiDelegate = self
        let page = UIViewController(); page.view = popup
        page.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem:.cancel,target:self,action:#selector(cancelLogin))
        loginPopup = popup; loginController?.pushViewController(page,animated:true)
        return popup
    }
    func webViewDidClose(_ webView: WKWebView) {
        guard webView === loginPopup else { return }
        loginPopup = nil; loginController?.popToRootViewController(animated:true); completeLogin()
    }
    @objc func commit(_ invoke: Invoke) {
        DispatchQueue.main.async {
            guard let attempt = self.loginToken, self.loginCompleting else { invoke.resolve(ConnectionFault.value("cancelled","login",retryable:false)); return }
            self.browser.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
            guard self.loginToken == attempt else { invoke.resolve(ConnectionFault.value("cancelled","login",retryable:false)); return }
            guard UIApplication.shared.applicationState == .active else { invoke.resolve(ConnectionFault.value("background_paused","identity")); return }
            guard let selection = LoginCookies.select(cookies), selection.token == self.activeToken else { invoke.resolve(ConnectionFault.value("authentication_expired","cookies",retryable:false)); return }
            self.emitStage("storage")
            let rows = selection.cookies.map { cookie -> [String: Any] in
                ["name": cookie.name, "value": cookie.value, "domain": cookie.domain, "path": cookie.path,
                 "secure": cookie.isSecure, "expires": cookie.expiresDate?.timeIntervalSince1970 ?? 0]
            }
            guard let data = try? SessionRecord.encode(token: selection.token, csrf: selection.csrf, cookies: rows) else { rejectNative(invoke, "Session storage failed."); return }
            do { try self.sessionTransaction.commit(data, read: self.readSession, write: self.writeSession, remove: self.removeSession) }
            catch { rejectNative(invoke, "Keychain could not commit and verify the session."); return }
            self.pendingCookies = []
            self.loginCommitted = true
            self.loginController?.topViewController?.navigationItem.leftBarButtonItem?.isEnabled = false
            invoke.resolve(["authToken":selection.token,"ct0":selection.csrf])
            }
        }
    }
    private func readKeychain(_ service: String, _ account: String) -> Data? {
        let query: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:service,
            kSecAttrAccount as String:account,kSecReturnData as String:true,kSecMatchLimit as String:kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary,&result) == errSecSuccess else { return nil }
        return result as? Data
    }
    private var sessionQuery: [String: Any] { [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.focusfeed.next",kSecAttrAccount as String:"x-session"] }
    private func readSession() throws -> Data? {
        var query = sessionQuery; query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?; let status = SecItemCopyMatching(query as CFDictionary,&result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else { throw SessionWriteError.save }
        return data
    }
    private func writeSession(_ data: Data) throws {
        let status = SecItemUpdate(sessionQuery as CFDictionary,[kSecValueData as String:data] as CFDictionary)
        if status == errSecItemNotFound {
            var entry = sessionQuery; entry[kSecValueData as String] = data; entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            guard SecItemAdd(entry as CFDictionary,nil) == errSecSuccess else { throw SessionWriteError.save }
        } else if status != errSecSuccess { throw SessionWriteError.save }
    }
    private func removeSession() throws {
        let status = SecItemDelete(sessionQuery as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw SessionWriteError.save }
    }
    @objc func rollback(_ invoke: Invoke) { DispatchQueue.main.async {
        do { try self.sessionTransaction.rollback(write:self.writeSession,remove:self.removeSession); self.loginCommitted = false; self.pendingCookies = []; self.activeToken = ""; self.needsReload = true; invoke.resolve() }
        catch { rejectNative(invoke, "Keychain could not restore the previous session.") }
    } }
    @objc func finalize(_ invoke: Invoke) { DispatchQueue.main.async {
        guard UIApplication.shared.applicationState == .active else { invoke.resolve(ConnectionFault.value("background_paused","storage")); return }
        self.sessionTransaction.finalize(); self.emitStage("connected")
        self.loginToken = nil; self.loginResume = nil; self.loginCompleting = false
        self.loginBrowser?.configuration.websiteDataStore.httpCookieStore.remove(self)
        self.loginBrowser?.stopLoading(); self.loginPopup?.stopLoading()
        self.loginBrowser = nil; self.loginPopup = nil; self.pendingCookies = []
        let controller = self.loginController; self.loginController = nil; self.chrome?.isHidden = false
        if let controller = controller { controller.dismiss(animated:true) { invoke.resolve() } }
        else { invoke.resolve() }
    } }
    @objc func migrateSession(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(SessionArgs.self)
        DispatchQueue.main.async {
            do {
                if let existing = try self.readSession(), let record = try? JSONSerialization.jsonObject(with:existing) as? [String:Any],
                   record["version"] as? Int == 1, record["authToken"] as? String == args.authToken, record["ct0"] as? String == args.ct0 { invoke.resolve(); return }
                let rows = self.savedCookies().filter { $0.name != "auth_token" && $0.name != "ct0" }.map { cookie -> [String:Any] in
                    ["name":cookie.name,"value":cookie.value,"domain":cookie.domain,"path":cookie.path,"secure":cookie.isSecure,"expires":cookie.expiresDate?.timeIntervalSince1970 ?? 0]
                }
                let data = try SessionRecord.encode(token:args.authToken,csrf:args.ct0,cookies:rows)
                try self.sessionTransaction.commit(data,read:self.readSession,write:self.writeSession,remove:self.removeSession)
                self.sessionTransaction.finalize(); invoke.resolve()
            } catch { rejectNative(invoke, "The previous session could not be migrated safely.") }
        }
    }
    private func savedCookies() -> [HTTPCookie] {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.focusfeed.next.ios", kSecAttrAccount as String: keychainAccount,
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        let legacyStatus = SecItemCopyMatching(query as CFDictionary, &result)
        let envelope = self.readKeychain("com.focusfeed.next", "x-session").flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String:Any] }
        let rows = envelope?["cookies"] as? [[String:Any]] ?? (legacyStatus == errSecSuccess ? (result as? Data).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [[String:Any]] } : nil) ?? []
        return rows.compactMap { row in
            var p: [HTTPCookiePropertyKey: Any] = [.name: row["name"] ?? "", .value: row["value"] ?? "",
                .domain: row["domain"] ?? "x.com", .path: row["path"] ?? "/", .secure: "TRUE"]
            if let expiry = row["expires"] as? Double, expiry > 0 { p[.expires] = Date(timeIntervalSince1970: expiry) }
            return HTTPCookie(properties: p)
        }
    }
    @objc func logout(_ invoke: Invoke) {
        DispatchQueue.main.async {
            let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: "com.focusfeed.next.ios", kSecAttrAccount as String: self.keychainAccount]
            let status = SecItemDelete(query as CFDictionary)
            guard status == errSecSuccess || status == errSecItemNotFound else { rejectNative(invoke, "Keychain could not remove the session."); return }
            self.activeToken = ""
            self.needsReload = true
            self.sessionTransaction.finalize()
            self.cancelTransportReads()
            self.browser.evaluateJavaScript("globalThis.__ffnReader?.cancel(undefined,true);", in: nil, in: self.world, completionHandler: nil)
            self.pendingCookies = []
            self.browser.stopLoading()
            self.browser.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { invoke.resolve() }
        }
    }
    @objc func request(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(RequestArgs.self)
        let allowed = ["Me", "HomeTimeline", "HomeLatestTimeline", "Bookmarks", "UserByScreenName", "UserTweets", "Following", "ListLatestTweetsTimeline", "DeleteBookmark", "Follow", "Unfollow"]
        guard allowed.contains(args.operation), args.authToken.count <= 512, args.ct0.count <= 512 else { rejectNative(invoke, "Unsupported request."); return }
        DispatchQueue.main.async {
            // A health/feed request from the previous session must not replace
            // cookies beneath the candidate account's identity check.
            guard LoginHandoff.permitsProviderRequest(loginOpen:self.loginToken != nil,authentication:args.context.authentication == true) else {
                rejectNative(invoke,"Request no longer needed."); return
            }
            if args.context.authentication == true {
                guard self.loginToken != nil, self.loginCompleting else { invoke.resolve(ConnectionFault.value("cancelled","login",retryable:false)); return }
                guard UIApplication.shared.applicationState == .active else { invoke.resolve(ConnectionFault.value("background_paused","identity")); return }
            }
            guard UIApplication.shared.applicationState != .background else { rejectNative(invoke, "The app is in the background."); return }
            let reply = RequestReply(invoke, deadline: args.context.deadline, id: args.context.id, authentication: args.context.authentication == true)
            let write = ["Follow", "Unfollow", "DeleteBookmark"].contains(args.operation)
            self.replies[args.context.id] = (reply,write,args.context.generation)
            reply.expired = { [weak self] in
                self?.browser.callAsyncJavaScript("globalThis.__ffnReader?.cancel(id);", arguments: ["id": args.context.id], in: nil, in: self?.world ?? WKContentWorld.page) { _ in }
                self?.replies.removeValue(forKey: args.context.id)
                self?.issuedIds.remove(args.context.id)
                self?.readyCallbacks.removeValue(forKey:args.context.id)
            }
            self.prepareCookies(args, reply) {
                guard reply.pending else { return }
                let perform = { if reply.pending { self.performRequest(args, reply) } }
                if !self.loading, !self.needsReload { perform() }
                else {
                    self.readyCallbacks[args.context.id] = (args.context.generation,perform)
                    if !self.loading {
                        self.loading = true
                        self.emitStage("transport")
                        self.transportEpoch &+= 1
                        self.transportNavigation = TransportDocument.load(in: self.browser)
                        if self.transportNavigation == nil { self.failTransport(stage: "transport_navigation") }
                    }
                }
            }
        }
    }
    // Cookie installation is serialized before any engine work. An identity
    // change clears the entire transient store, including supporting cookies.
    private func prepareCookies(_ args: RequestArgs, _ reply: RequestReply, _ ready: @escaping () -> Void) {
        cookieJobs.append {
            let finish = { self.cookieBusy = false; self.drainCookies() }
            guard reply.pending else { finish(); return }
            // The server can rotate ct0 during navigation. Reinstalling the
            // captured value on every request would replace the current cookie.
            if self.activeToken == args.authToken { ready(); finish(); return }
            let install = {
                guard reply.pending else { finish(); return }
                let cookies = self.pendingCookies.first(where: { $0.name == "auth_token" })?.value == args.authToken ? self.pendingCookies : self.savedCookies()
                let matching = cookies.filter { $0.name != "auth_token" && $0.name != "ct0" }
                let base = ["auth_token": args.authToken, "ct0": args.ct0].compactMap { name, value in
                    HTTPCookie(properties: [.name: name, .value: value, .domain: ".x.com", .path: "/", .secure: "TRUE"])
                }
                let group = DispatchGroup()
                for cookie in matching + base {
                    group.enter(); self.browser.configuration.websiteDataStore.httpCookieStore.setCookie(cookie) { group.leave() }
                }
                group.notify(queue: .main) {
                    if reply.pending { self.activeToken = args.authToken; ready() }
                    else { self.activeToken = ""; self.needsReload = true }
                    finish()
                }
            }
            if self.activeToken != args.authToken {
                self.connectionTimings.removeAll()
                self.transportEpoch &+= 1; self.transportNavigation = nil
                self.browser.stopLoading(); self.loading = false; self.needsReload = true
                self.browser.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast, completionHandler: install)
            } else { install() }
        }
        drainCookies()
    }
    private func drainCookies() {
        guard !cookieBusy, !cookieJobs.isEmpty else { return }
        cookieBusy = true; cookieJobs.removeFirst()()
    }
    private func performRequest(_ args: RequestArgs, _ reply: RequestReply) {
        browser.configuration.websiteDataStore.httpCookieStore.getAllCookies { [weak self] cookies in
            guard let self = self, reply.pending else { return }
            guard let selection = LoginCookies.select(cookies), selection.token == args.authToken else {
                reply.resolve(ConnectionFault.value("authentication_expired","cookies",id:args.context.id,retryable:false)); return
            }
            if reply.authentication { self.pendingCookies = selection.cookies }
            self.executeRequest(args,reply,csrf:selection.csrf,identity:LoginCookies.activeUserId(selection.cookies))
        }
    }
    private func executeRequest(_ args: RequestArgs, _ reply: RequestReply, csrf: String, identity: String?) {
        if args.operation == "Me" { emitStage("identity") }
        let script = NativeReaderScript.source
        issuedIds.insert(args.context.id)
        let source = "if (!globalThis.__ffnReader) {" + script + ";globalThis.__ffnReader = FfnReader;}\nreturn await globalThis.__ffnReader.requestSafe(operation, variables, csrf, context);"
        browser.callAsyncJavaScript(source, arguments: ["operation": args.operation,
            "variables": args.variables.mapValues { $0.value }, "csrf": csrf,
            "context": ["id": args.context.id, "generation": args.context.generation, "priority": args.context.priority, "deadline": args.context.deadline,"authentication":args.context.authentication == true]], in: nil, in: world) { result in
            self.replies.removeValue(forKey: args.context.id)
            self.issuedIds.remove(args.context.id)
            switch result {
            case .success(let value):
                guard var response = value as? [String: Any] else { reply.reject("Twitter returned an unreadable response."); return }
                if !reply.pending { return }
                if var timing = response["timing"] as? [String: Any] {
                    timing["nativeMs"] = reply.elapsedMs
                    self.connectionTimings.append(timing)
                    if self.connectionTimings.count > 32 { self.connectionTimings.removeFirst() }
                }
                if args.operation == "Me", let identity = identity {
                    var body = response["body"] as? [String: Any] ?? ["users": response["body"] ?? []]
                    body["activeUserId"] = identity; response["body"] = body
                }
                reply.resolve(response)
            case .failure(let error):
                reply.resolve(ConnectionFault.transport(stage: "transport_script", id: args.context.id, error: error))
            }
        }
    }
    @objc func configureChrome(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(ChromeArgs.self)
        DispatchQueue.main.async {
            guard args.labels.count == 5, args.routes.count == 5, let webview = self.reader, let parent = webview.superview else { rejectNative(invoke, "Reader chrome is not ready."); return }
            self.routes = args.routes
            self.nativeHaptics = args.haptics
            if self.chrome == nil {
                let effect: UIVisualEffect
                #if compiler(>=6.2)
                if #available(iOS 26.0, *), !UIAccessibility.isReduceTransparencyEnabled {
                    effect = UIGlassEffect(style: .regular)
                } else { effect = UIBlurEffect(style: .systemMaterial) }
                #else
                effect = UIBlurEffect(style: .systemMaterial)
                #endif
                let bar = UIVisualEffectView(effect: effect)
                bar.translatesAutoresizingMaskIntoConstraints = false
                bar.layer.cornerRadius = 30
                bar.clipsToBounds = true
                let tabs = UITabBar()
                tabs.translatesAutoresizingMaskIntoConstraints = false
                tabs.delegate = self
                tabs.itemPositioning = .fill
                tabs.showsLargeContentViewer = true
                tabs.addInteraction(UILargeContentViewerInteraction())
                bar.contentView.addSubview(tabs)
                parent.addSubview(bar)
                let height = bar.heightAnchor.constraint(equalToConstant: 64)
                self.chromeHeight = height
                NSLayoutConstraint.activate([
                    bar.leadingAnchor.constraint(equalTo: webview.leadingAnchor, constant: 12),
                    bar.trailingAnchor.constraint(equalTo: webview.trailingAnchor, constant: -12),
                    bar.bottomAnchor.constraint(equalTo: parent.safeAreaLayoutGuide.bottomAnchor, constant: -6),
                    height,
                    tabs.leadingAnchor.constraint(equalTo: bar.contentView.leadingAnchor),
                    tabs.trailingAnchor.constraint(equalTo: bar.contentView.trailingAnchor),
                    tabs.topAnchor.constraint(equalTo: bar.contentView.topAnchor, constant: 4),
                    tabs.bottomAnchor.constraint(equalTo: bar.contentView.bottomAnchor, constant: -4)
                ])
                self.tabBar = tabs
                self.chrome = bar
            }
            self.chrome?.overrideUserInterfaceStyle = args.dark ? .dark : .light
            self.chrome?.semanticContentAttribute = args.rtl ? .forceRightToLeft : .forceLeftToRight
            self.chrome?.contentView.subviews.forEach { $0.semanticContentAttribute = args.rtl ? .forceRightToLeft : .forceLeftToRight }
            self.chrome?.isHidden = !args.visible
            self.chrome?.backgroundColor = UIAccessibility.isReduceTransparencyEnabled ? .secondarySystemBackground : .clear
            let accent = self.color(args.accent) ?? .systemBlue
            let appearance = UITabBarAppearance()
            appearance.configureWithTransparentBackground()
            appearance.shadowColor = .clear
            for layout in [appearance.stackedLayoutAppearance, appearance.inlineLayoutAppearance, appearance.compactInlineLayoutAppearance] {
                layout.normal.iconColor = .secondaryLabel
                layout.normal.titleTextAttributes = [.foregroundColor: UIColor.secondaryLabel, .font: UIFont.systemFont(ofSize: 10, weight: .medium)]
                layout.selected.iconColor = accent
                layout.selected.titleTextAttributes = [.foregroundColor: accent, .font: UIFont.systemFont(ofSize: 10, weight: .semibold)]
            }
            self.tabBar?.standardAppearance = appearance
            self.tabBar?.scrollEdgeAppearance = appearance
            self.tabBar?.tintColor = accent
            self.tabBar?.semanticContentAttribute = args.rtl ? .forceRightToLeft : .forceLeftToRight
            let items = self.routes.enumerated().map { index, route -> UITabBarItem in
                let item = UITabBarItem(title: args.labels[index], image: UIImage(systemName: self.symbol(for: route)), tag: index)
                item.accessibilityLabel = args.accessibilityLabels?.count == 5 ? args.accessibilityLabels?[index] : args.labels[index]
                return item
            }
            self.tabBar?.setItems(items, animated: false)
            let selected = self.routes.firstIndex(of: args.selected) ?? 4
            self.tabBar?.selectedItem = items[selected]
            self.refreshGlass()
            invoke.resolve(["native": true])
        }
    }
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        guard routes.indices.contains(item.tag) else { return }
        if nativeHaptics { UISelectionFeedbackGenerator().selectionChanged() }
        let route = routes[item.tag]
        if let data = try? JSONSerialization.data(withJSONObject: route, options: .fragmentsAllowed), let json = String(data:data,encoding:.utf8) {
            reader?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('ffn-native-route', {detail:\(json)}));")
        }
    }
    private func symbol(for route: String) -> String {
        switch route { case "following": return "square.stack"; case "focus": return "scope"; case "bookmarks": return "bookmark"; case "accounts": return "person.2"; case "originals": return "pencil.line"; case "groups": return "books.vertical"; case "search": return "magnifyingglass"; default: return "ellipsis" }
    }
    private func color(_ value: String) -> UIColor? {
        var hex = value.replacingOccurrences(of: "#",with: "")
        if hex.count == 3 { hex = hex.map { "\($0)\($0)" }.joined() }
        guard hex.count == 6, let rgb = UInt32(hex,radix:16) else { return nil }
        return UIColor(red:CGFloat((rgb >> 16) & 255)/255,green:CGFloat((rgb >> 8) & 255)/255,blue:CGFloat(rgb & 255)/255,alpha:1)
    }
    private func refreshGlass() {
        guard let chrome = chrome else { return }
        let height = max(64, (tabBar?.sizeThatFits(CGSize(width: chrome.bounds.width, height: 0)).height ?? 49) + 8)
        chromeHeight?.constant = height
        chrome.layoutIfNeeded()
        reader?.evaluateJavaScript("document.documentElement.style.setProperty('--native-tab-height','\(height + 12)px');")
        if UIAccessibility.isReduceTransparencyEnabled { chrome.effect = nil; chrome.backgroundColor = .secondarySystemBackground }
        else {
            chrome.backgroundColor = .clear
            #if compiler(>=6.2)
            if #available(iOS 26.0, *) { chrome.effect = UIGlassEffect(style:.regular) }
            else { chrome.effect = UIBlurEffect(style:.systemMaterial) }
            #else
            chrome.effect = UIBlurEffect(style:.systemMaterial)
            #endif
        }
    }
}
@_cdecl("init_plugin_ios_reader")
func initPlugin() -> Plugin { IosReaderPlugin() }
