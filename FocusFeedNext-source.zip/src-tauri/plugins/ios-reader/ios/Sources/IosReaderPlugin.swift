import Tauri
import UIKit
import WebKit
import Security

private struct RequestArgs: Decodable {
    let operation: String
    let variables: [String: AnyCodable]
    let authToken: String
    let ct0: String
    let context: RequestContext
}
private struct RequestContext: Decodable { let id: String; let generation: UInt64; let priority: Int; let deadline: UInt64 }
// JSON values decoded without ever evaluating caller-provided JavaScript.
private struct AnyCodable: Decodable {
    let value: Any
    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { value = NSNull() }
        else if let v = try? c.decode(Bool.self) { value = v }
        else if let v = try? c.decode(Int.self) { value = v }
        else if let v = try? c.decode(Double.self) { value = v }
        else { value = try c.decode(String.self) }
    }
}
private struct ChromeArgs: Decodable {
    let labels: [String]
    let selected: String
    let dark: Bool
    let visible: Bool
    let routes: [String]
    let accent: String
    let haptics: Bool
    let rtl: Bool
}
private struct ShareArgs: Decodable { let bundle: String }
private struct SessionArgs: Decodable { let authToken: String; let ct0: String }
private struct CancelArgs: Decodable { let beforeGeneration: UInt64? }
// WebKit completion, navigation recovery and the deadline race on the main queue.
// Exactly one result reaches Rust even if WebKit completes after the deadline.
private final class RequestReply {
    private let invoke: Invoke
    private(set) var pending = true
    var expired: (() -> Void)?
    init(_ invoke: Invoke, deadline: UInt64) {
        self.invoke = invoke
        let seconds = min(75, max(0, Double(deadline) / 1000 - Date().timeIntervalSince1970))
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) { [weak self] in
            guard self?.pending == true else { return }
            self?.expired?()
            self?.reject("Twitter took too long to respond. Please try again.")
        }
    }
    func resolve(_ value: [String: Any]) {
        guard pending else { return }; pending = false; invoke.resolve(value)
    }
    func reject(_ message: String) {
        guard pending else { return }; pending = false; invoke.reject(message)
    }
}
private final class LoginController: UIViewController, UIAdaptivePresentationControllerDelegate {
    var cancel: (() -> Void)?
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isBeingDismissed || navigationController?.isBeingDismissed == true { cancel?() }
    }
}

class IosReaderPlugin: Plugin, WKNavigationDelegate, WKHTTPCookieStoreObserver {
    private weak var reader: WKWebView?
    private var browser: WKWebView!
    private var loginBrowser: WKWebView?
    private var deviceRuntime: DeviceRuntime?
    private var replies: [String: (RequestReply, Bool, UInt64)] = [:]
    private var issuedIds = Set<String>()
    private var transportReady = false
    private var ruleCallbacks: [() -> Void] = []
    private var needsReload = true
    private var nativeHaptics = true
    private let sessionTransaction = SessionTransaction()
    private var chromeHeight: NSLayoutConstraint?
    private var loginInvoke: Invoke?
    private var loginController: UINavigationController?
    private var pendingCookies: [HTTPCookie] = []
    private var chrome: UIVisualEffectView?
    private var chromeButtons: [UIButton] = []
    private var readyCallbacks: [String: (UInt64, () -> Void)] = [:]
    private var loading = false
    private var activeToken = ""
    private var cookieJobs: [() -> Void] = []
    private var cookieBusy = false
    private var routes = ["following", "focus", "bookmarks", "accounts", "more"]
    private let world = WKContentWorld.world(name: "FocusFeedPrivateTransport")
    private let keychainAccount = "twitter-browser-cookies-v1"

    override func load(webview: WKWebView) {
        reader = webview
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        browser = WKWebView(frame: .zero, configuration: config)
        // Keep WebKit attached to the app's active hierarchy without exposing
        // the transport document to touch or accessibility navigation.
        browser.frame = CGRect(x:-2,y:-2,width:1,height:1)
        browser.isUserInteractionEnabled = false
        browser.accessibilityElementsHidden = true
        webview.addSubview(browser)
        browser.navigationDelegate = self
        let rules = TransportRules.encoded
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "ffn-transport-v1", encodedContentRuleList: rules) { [weak self] list, _ in
            guard let self = self else { return }
            if let list = list { self.browser.configuration.userContentController.add(list); self.transportReady = true }
            let callbacks = self.ruleCallbacks; self.ruleCallbacks.removeAll(); callbacks.forEach { $0() }
        }
        deviceRuntime = DeviceRuntime()
        deviceRuntime?.changed = { [weak self] snapshot in
            guard let self = self else { return }
            if snapshot["foreground"] as? Bool == false { self.cancelTransportReads(all:true) }
            if let data = try? JSONSerialization.data(withJSONObject: snapshot), let json = String(data: data, encoding: .utf8) {
                self.reader?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('ffn-runtime', {detail:\(json)}));")
            }
            self.refreshGlass()
        }
        if #available(iOS 16.4, *) { browser.isInspectable = false }
    }

    @objc func login(_ invoke: Invoke) {
        DispatchQueue.main.async {
            guard self.loginInvoke == nil else { invoke.reject("Sign-in is already open."); return }
            guard let root = self.reader?.window?.rootViewController else { invoke.reject("The reader is not ready."); return }
            self.loginInvoke = invoke
            self.pendingCookies = []
            self.cancelTransportReads()
            let config = WKWebViewConfiguration()
            config.websiteDataStore = .nonPersistent()
            let login = WKWebView(frame: .zero, configuration: config)
            login.navigationDelegate = self
            config.websiteDataStore.httpCookieStore.add(self)
            if #available(iOS 16.4, *) { login.isInspectable = false }
            self.loginBrowser = login
            let page = LoginController()
            page.title = "Sign in to Twitter"
            page.view = login
            page.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(self.cancelLogin))
            page.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Continue", style: .done, target: self, action: #selector(self.completeLogin))
            page.cancel = { [weak self] in self?.cancelLogin() }
            let nav = UINavigationController(rootViewController: page)
            nav.modalPresentationStyle = .fullScreen
            self.loginController = nav
            self.chrome?.isHidden = true
            root.present(nav, animated: true)
            login.load(URLRequest(url: URL(string: "https://x.com/i/flow/login")!))
        }
    }
    @objc private func cancelLogin() {
        guard let invoke = loginInvoke else { return }
        loginInvoke = nil
        loginController?.dismiss(animated: true)
        loginController = nil
        loginBrowser?.stopLoading()
        loginBrowser = nil
        pendingCookies = []
        chrome?.isHidden = false
        invoke.reject("Sign-in was cancelled.")
    }
    @objc private func completeLogin() {
        guard let invoke = loginInvoke else { return }
        guard let login = loginBrowser else { return }
        login.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
            guard self.loginInvoke != nil else { return }
            let xCookies = cookies.filter { $0.domain == "x.com" || $0.domain == ".x.com" || $0.domain == "twitter.com" || $0.domain == ".twitter.com" }
            guard let token = xCookies.first(where: { $0.name == "auth_token" }),
                  let csrf = xCookies.first(where: { $0.name == "ct0" }) else { return }
            self.pendingCookies = xCookies
            self.loginInvoke = nil
            self.loginController?.dismiss(animated: true)
            self.loginController = nil
            self.loginBrowser?.stopLoading()
            self.loginBrowser = nil
            self.chrome?.isHidden = false
            // Resolved only to Rust's plugin handle. The React command receives a SessionSnapshot.
            invoke.resolve(["authToken": token.value, "ct0": csrf.value])
        }
    }
    func cookiesDidChange(in cookieStore: WKHTTPCookieStore) {
        guard loginInvoke != nil, loginBrowser?.url?.host == "x.com", loginBrowser?.url?.path == "/home" else { return }
        completeLogin()
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if webView === loginBrowser { if webView.url?.path == "/home" { completeLogin() }; return }
        loading = false
        needsReload = webView.url?.host != "x.com"
        if loginInvoke != nil, webView.url?.path == "/home" { completeLogin() }
        let callbacks = readyCallbacks
        readyCallbacks.removeAll()
        callbacks.values.forEach { $0.1() }
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if webView === loginBrowser { cancelLogin(); return }
        failTransport()
        loading = false
        let callbacks = readyCallbacks
        readyCallbacks.removeAll()
        callbacks.values.forEach { $0.1() }
        if loginInvoke != nil { cancelLogin() }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if webView === loginBrowser { return }
        failTransport()
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if webView !== loginBrowser { failTransport() }
    }
    private func failTransport() {
        loading = false
        needsReload = true
        readyCallbacks.removeAll()
        for (_, (reply, _, _)) in replies { reply.reject("Twitter transport was interrupted. Retry the read request.") }
        replies.removeAll()
        issuedIds.removeAll()
        browser.stopLoading()
    }
    @objc func runtime(_ invoke: Invoke) {
        DispatchQueue.main.async {
            let snapshot: [String: Any] = self.deviceRuntime?.snapshot() ?? [:]
            invoke.resolve(snapshot)
        }
    }
    @objc func sharePreferences(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(ShareArgs.self)
        DispatchQueue.main.async {
            guard let root = self.reader?.window?.rootViewController,
                  let data = args.bundle.data(using:.utf8),data.count <= 32768 else { invoke.reject("Preferences could not be exported."); return }
            let file = FileManager.default.temporaryDirectory.appendingPathComponent("FocusFeedNext-preferences-\(UUID().uuidString).json")
            do { try data.write(to:file,options:.atomic) } catch { invoke.reject("Preferences could not be exported."); return }
            let sheet = UIActivityViewController(activityItems:[file],applicationActivities:nil)
            sheet.popoverPresentationController?.sourceView = root.view
            sheet.popoverPresentationController?.sourceRect = CGRect(x:root.view.bounds.midX,y:root.view.bounds.midY,width:1,height:1)
            sheet.completionWithItemsHandler = { _,_,_,_ in try? FileManager.default.removeItem(at:file); invoke.resolve() }
            root.present(sheet,animated:true)
        }
    }
    @objc func cancelReads(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(CancelArgs.self)
        DispatchQueue.main.async { self.cancelTransportReads(beforeGeneration:args.beforeGeneration); invoke.resolve() }
    }
    private func cancelTransportReads(beforeGeneration: UInt64? = nil, all: Bool = false) {
        for (id, (reply, write, generation)) in replies where (!write || (all && !issuedIds.contains(id))) && (beforeGeneration == nil || generation < beforeGeneration!) {
            reply.reject("Request no longer needed."); replies.removeValue(forKey:id); readyCallbacks.removeValue(forKey:id)
        }
        browser.callAsyncJavaScript("globalThis.__ffnReader?.cancel(undefined,all,beforeGeneration);", arguments:["all":all,"beforeGeneration":beforeGeneration.map { NSNumber(value:$0) } ?? NSNumber(value:Double.greatestFiniteMagnitude)], in:nil,in:world) { _ in }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url, url.scheme == "https", let host = url.host,
              host == "x.com" || host.hasSuffix(".x.com") || host == "twitter.com" || host.hasSuffix(".twitter.com") || host == "accounts.google.com" || host == "appleid.apple.com" else {
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }
    @objc func commit(_ invoke: Invoke) {
        DispatchQueue.main.async {
            let rows = self.pendingCookies.compactMap { cookie -> [String: Any]? in
                ["name": cookie.name, "value": cookie.value, "domain": cookie.domain, "path": cookie.path,
                 "secure": cookie.isSecure, "expires": cookie.expiresDate?.timeIntervalSince1970 ?? 0]
            }
            guard let token = self.pendingCookies.first(where: { $0.name == "auth_token" })?.value,
                  let csrf = self.pendingCookies.first(where: { $0.name == "ct0" })?.value,
                  let data = try? SessionRecord.encode(token: token, csrf: csrf, cookies: rows) else { invoke.reject("Session storage failed."); return }
            do { try self.sessionTransaction.commit(data, read: self.readSession, write: self.writeSession, remove: self.removeSession) }
            catch { invoke.reject("Keychain could not commit and verify the session."); return }
            self.pendingCookies = []
            invoke.resolve()
        }
    }
    private func readKeychain(_ service: String, _ account: String) -> Data? {
        let query: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:service,
            kSecAttrAccount as String:account,kSecReturnData as String:true,kSecMatchLimit as String:kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary,&result) == errSecSuccess else { return nil }
        return result as? Data
    }
    private var sessionQuery: [String: Any] { [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.focusfeed.next",kSecAttrAccount as String:"x-session"] }
    private func readSession() throws -> Data? {
        var query = sessionQuery; query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?; let status = SecItemCopyMatching(query as CFDictionary,&result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else { throw SessionWriteError.save }
        return data
    }
    private func writeSession(_ data: Data) throws {
        let status = SecItemUpdate(sessionQuery as CFDictionary,[kSecValueData as String:data] as CFDictionary)
        if status == errSecItemNotFound {
            var entry = sessionQuery; entry[kSecValueData as String] = data; entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            guard SecItemAdd(entry as CFDictionary,nil) == errSecSuccess else { throw SessionWriteError.save }
        } else if status != errSecSuccess { throw SessionWriteError.save }
    }
    private func removeSession() throws {
        let status = SecItemDelete(sessionQuery as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw SessionWriteError.save }
    }
    @objc func rollback(_ invoke: Invoke) { DispatchQueue.main.async {
        do { try self.sessionTransaction.rollback(write:self.writeSession,remove:self.removeSession); self.pendingCookies = []; self.needsReload = true; invoke.resolve() }
        catch { invoke.reject("Keychain could not restore the previous session.") }
    } }
    @objc func finalize(_ invoke: Invoke) { DispatchQueue.main.async { self.sessionTransaction.finalize(); invoke.resolve() } }
    @objc func migrateSession(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(SessionArgs.self)
        DispatchQueue.main.async {
            do {
                if let existing = try self.readSession(), let record = try? JSONSerialization.jsonObject(with:existing) as? [String:Any],
                   record["version"] as? Int == 1, record["authToken"] as? String == args.authToken, record["ct0"] as? String == args.ct0 { invoke.resolve(); return }
                let rows = self.savedCookies().filter { $0.name != "auth_token" && $0.name != "ct0" }.map { cookie -> [String:Any] in
                    ["name":cookie.name,"value":cookie.value,"domain":cookie.domain,"path":cookie.path,"secure":cookie.isSecure,"expires":cookie.expiresDate?.timeIntervalSince1970 ?? 0]
                }
                let data = try SessionRecord.encode(token:args.authToken,csrf:args.ct0,cookies:rows)
                try self.sessionTransaction.commit(data,read:self.readSession,write:self.writeSession,remove:self.removeSession)
                self.sessionTransaction.finalize(); invoke.resolve()
            } catch { invoke.reject("The previous session could not be migrated safely.") }
        }
    }
    private func savedCookies() -> [HTTPCookie] {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.focusfeed.next.ios", kSecAttrAccount as String: keychainAccount,
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        let legacyStatus = SecItemCopyMatching(query as CFDictionary, &result)
        let envelope = self.readKeychain("com.focusfeed.next", "x-session").flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String:Any] }
        let rows = envelope?["cookies"] as? [[String:Any]] ?? (legacyStatus == errSecSuccess ? (result as? Data).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [[String:Any]] } : nil) ?? []
        return rows.compactMap { row in
            var p: [HTTPCookiePropertyKey: Any] = [.name: row["name"] ?? "", .value: row["value"] ?? "",
                .domain: row["domain"] ?? "x.com", .path: row["path"] ?? "/", .secure: "TRUE"]
            if let expiry = row["expires"] as? Double, expiry > 0 { p[.expires] = Date(timeIntervalSince1970: expiry) }
            return HTTPCookie(properties: p)
        }
    }
    @objc func logout(_ invoke: Invoke) {
        DispatchQueue.main.async {
            let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: "com.focusfeed.next.ios", kSecAttrAccount as String: self.keychainAccount]
            let status = SecItemDelete(query as CFDictionary)
            guard status == errSecSuccess || status == errSecItemNotFound else { invoke.reject("Keychain could not remove the session."); return }
            self.activeToken = ""
            self.needsReload = true
            self.sessionTransaction.finalize()
            self.cancelTransportReads()
            self.browser.evaluateJavaScript("globalThis.__ffnReader?.cancel(undefined,true);", in: nil, in: self.world, completionHandler: nil)
            self.pendingCookies = []
            self.browser.stopLoading()
            self.browser.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { invoke.resolve() }
        }
    }
    @objc func request(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(RequestArgs.self)
        let allowed = ["Me", "HomeTimeline", "HomeLatestTimeline", "Bookmarks", "UserByScreenName", "UserTweets", "Following", "ListLatestTweetsTimeline", "DeleteBookmark", "Follow", "Unfollow"]
        guard allowed.contains(args.operation), args.authToken.count <= 512, args.ct0.count <= 512 else { invoke.reject("Unsupported request."); return }
        DispatchQueue.main.async {
            guard UIApplication.shared.applicationState != .background else { invoke.reject("The app is in the background."); return }
            let reply = RequestReply(invoke, deadline: args.context.deadline)
            let write = ["Follow", "Unfollow", "DeleteBookmark"].contains(args.operation)
            self.replies[args.context.id] = (reply,write,args.context.generation)
            reply.expired = { [weak self] in
                self?.browser.callAsyncJavaScript("globalThis.__ffnReader?.cancel(id);", arguments: ["id": args.context.id], in: nil, in: self?.world ?? WKContentWorld.page) { _ in }
                self?.replies.removeValue(forKey: args.context.id)
                self?.issuedIds.remove(args.context.id)
                self?.readyCallbacks.removeValue(forKey:args.context.id)
            }
            self.prepareCookies(args, reply) {
                guard reply.pending else { return }
                let navigate = {
                guard reply.pending else { return }
                guard self.transportReady else { reply.reject("Transport configuration could not initialize."); return }
                let perform = { if reply.pending { self.performRequest(args, reply) } }
                if self.browser.url?.host == "x.com", !self.loading, !self.needsReload { perform() }
                else {
                    self.readyCallbacks[args.context.id] = (args.context.generation,perform)
                    if !self.loading {
                        self.loading = true
                        self.browser.load(URLRequest(url: URL(string: "https://x.com/home")!))
                    }
                }
                }
                if self.transportReady { navigate() } else { self.ruleCallbacks.append(navigate) }
            }
        }
    }
    // Cookie installation is serialized before any engine work. An identity
    // change clears the entire transient store, including supporting cookies.
    private func prepareCookies(_ args: RequestArgs, _ reply: RequestReply, _ ready: @escaping () -> Void) {
        cookieJobs.append {
            let finish = { self.cookieBusy = false; self.drainCookies() }
            guard reply.pending else { finish(); return }
            let install = {
                guard reply.pending else { finish(); return }
                let cookies = self.pendingCookies.first(where: { $0.name == "auth_token" })?.value == args.authToken ? self.pendingCookies : self.savedCookies()
                let matching = cookies.filter { $0.name != "auth_token" && $0.name != "ct0" }
                let base = ["auth_token": args.authToken, "ct0": args.ct0].compactMap { name, value in
                    HTTPCookie(properties: [.name: name, .value: value, .domain: ".x.com", .path: "/", .secure: "TRUE"])
                }
                let group = DispatchGroup()
                for cookie in matching + base {
                    group.enter(); self.browser.configuration.websiteDataStore.httpCookieStore.setCookie(cookie) { group.leave() }
                }
                group.notify(queue: .main) { self.activeToken = args.authToken; if reply.pending { ready() }; finish() }
            }
            if self.activeToken != args.authToken {
                self.browser.stopLoading(); self.loading = false; self.needsReload = true
                self.browser.configuration.websiteDataStore.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast, completionHandler: install)
            } else { install() }
        }
        drainCookies()
    }
    private func drainCookies() {
        guard !cookieBusy, !cookieJobs.isEmpty else { return }
        cookieBusy = true; cookieJobs.removeFirst()()
    }
    private func performRequest(_ args: RequestArgs, _ reply: RequestReply) {
        if !transportReady {
            ruleCallbacks.append { [weak self] in
                guard reply.pending else { return }
                guard let self = self, self.transportReady else { reply.reject("Transport configuration could not initialize."); return }
                self.performRequest(args,reply)
            }
            return
        }
        let script = NativeReaderScript.source
        issuedIds.insert(args.context.id)
        let source = "if (!globalThis.__ffnReader) {" + script + ";globalThis.__ffnReader = FfnReader;}\nreturn await globalThis.__ffnReader.request(operation, variables, csrf, context);"
        browser.callAsyncJavaScript(source, arguments: ["operation": args.operation,
            "variables": args.variables.mapValues { $0.value }, "csrf": args.ct0,
            "context": ["id": args.context.id, "generation": args.context.generation, "priority": args.context.priority, "deadline": args.context.deadline]], in: nil, in: world) { result in
            self.replies.removeValue(forKey: args.context.id)
            self.issuedIds.remove(args.context.id)
            switch result {
            case .success(let value):
                guard let response = value as? [String: Any] else { reply.reject("Twitter returned an unreadable response."); return }
                reply.resolve(response)
            case .failure:
                reply.reject("Twitter could not be reached. Check your connection and sign in again if needed.")
            }
        }
    }
    @objc func configureChrome(_ invoke: Invoke) throws {
        let args = try invoke.parseArgs(ChromeArgs.self)
        DispatchQueue.main.async {
            guard args.labels.count == 5, args.routes.count == 5, let webview = self.reader, let parent = webview.superview else { invoke.reject("Reader chrome is not ready."); return }
            self.routes = args.routes
            self.nativeHaptics = args.haptics
            if self.chrome == nil {
                let effect: UIVisualEffect
                #if compiler(>=6.2)
                if #available(iOS 26.0, *), !UIAccessibility.isReduceTransparencyEnabled {
                    effect = UIGlassEffect(style: .regular)
                } else { effect = UIBlurEffect(style: .systemMaterial) }
                #else
                effect = UIBlurEffect(style: .systemMaterial)
                #endif
                let bar = UIVisualEffectView(effect: effect)
                bar.translatesAutoresizingMaskIntoConstraints = false
                bar.layer.cornerRadius = 30
                bar.clipsToBounds = true
                let stack = UIStackView()
                stack.translatesAutoresizingMaskIntoConstraints = false
                stack.distribution = .fillEqually
                let symbols = self.routes.map { self.symbol(for: $0) }
                for index in 0..<5 {
                    let button = UIButton(type: .system)
                    button.tag = index
                    var config = UIButton.Configuration.plain()
                    config.image = UIImage(systemName: symbols[index])
                    config.imagePlacement = .top
                    config.imagePadding = 3
                    config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { value in
                        var out = value; out.font = UIFontMetrics(forTextStyle: .caption2).scaledFont(for: .systemFont(ofSize: 10, weight: .medium)); return out
                    }
                    button.configuration = config
                    button.addTarget(self, action: #selector(self.selectTab(_:)), for: .touchUpInside)
                    stack.addArrangedSubview(button)
                    self.chromeButtons.append(button)
                }
                bar.contentView.addSubview(stack)
                parent.addSubview(bar)
                let height = bar.heightAnchor.constraint(equalToConstant:64)
                self.chromeHeight = height
                NSLayoutConstraint.activate([
                    bar.leadingAnchor.constraint(equalTo: webview.leadingAnchor, constant: 12),
                    bar.trailingAnchor.constraint(equalTo: webview.trailingAnchor, constant: -12),
                    bar.bottomAnchor.constraint(equalTo: parent.safeAreaLayoutGuide.bottomAnchor, constant: -6),
                    height,
                    stack.leadingAnchor.constraint(equalTo: bar.contentView.leadingAnchor, constant: 5),
                    stack.trailingAnchor.constraint(equalTo: bar.contentView.trailingAnchor, constant: -5),
                    stack.topAnchor.constraint(equalTo: bar.contentView.topAnchor), stack.bottomAnchor.constraint(equalTo: bar.contentView.bottomAnchor)
                ])
                self.chrome = bar
            }
            self.chrome?.overrideUserInterfaceStyle = args.dark ? .dark : .light
            self.chrome?.semanticContentAttribute = args.rtl ? .forceRightToLeft : .forceLeftToRight
            self.chrome?.contentView.subviews.forEach { $0.semanticContentAttribute = args.rtl ? .forceRightToLeft : .forceLeftToRight }
            self.chrome?.isHidden = !args.visible
            self.chrome?.backgroundColor = UIAccessibility.isReduceTransparencyEnabled ? .secondarySystemBackground : .clear
            self.refreshGlass()
            let accent = self.color(args.accent) ?? .systemBlue
            for (index, button) in self.chromeButtons.enumerated() {
                button.configuration?.image = UIImage(systemName: self.symbol(for: self.routes[index]))
                button.configuration?.title = args.labels[index]
                button.accessibilityLabel = args.labels[index]
                let selected = self.routes[index] == args.selected || (index == 4 && !self.routes.contains(args.selected))
                button.tintColor = selected ? accent : .secondaryLabel
                button.accessibilityTraits = selected ? [.button, .selected] : [.button]
            }
            invoke.resolve(["native": true])
        }
    }
    @objc private func selectTab(_ sender: UIButton) {
        guard routes.indices.contains(sender.tag) else { return }
        if nativeHaptics { UISelectionFeedbackGenerator().selectionChanged() }
        let route = routes[sender.tag]
        if let data = try? JSONSerialization.data(withJSONObject: route, options: .fragmentsAllowed), let json = String(data:data,encoding:.utf8) {
            reader?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('ffn-native-route', {detail:\(json)}));")
        }
    }
    private func symbol(for route: String) -> String {
        switch route { case "following": return "square.stack"; case "focus": return "scope"; case "bookmarks": return "bookmark"; case "accounts": return "person.2"; case "originals": return "pencil.line"; case "groups": return "books.vertical"; case "search": return "magnifyingglass"; default: return "ellipsis" }
    }
    private func color(_ value: String) -> UIColor? {
        var hex = value.replacingOccurrences(of: "#",with: "")
        if hex.count == 3 { hex = hex.map { "\($0)\($0)" }.joined() }
        guard hex.count == 6, let rgb = UInt32(hex,radix:16) else { return nil }
        return UIColor(red:CGFloat((rgb >> 16) & 255)/255,green:CGFloat((rgb >> 8) & 255)/255,blue:CGFloat(rgb & 255)/255,alpha:1)
    }
    private func refreshGlass() {
        guard let chrome = chrome else { return }
        let height = max(64, 42 + UIFont.preferredFont(forTextStyle:.caption2).pointSize * 1.5)
        chromeHeight?.constant = height
        chromeButtons.forEach { $0.setNeedsUpdateConfiguration() }
        reader?.evaluateJavaScript("document.documentElement.style.setProperty('--native-tab-height','\(height + 12)px');")
        if UIAccessibility.isReduceTransparencyEnabled { chrome.effect = nil; chrome.backgroundColor = .secondarySystemBackground }
        else {
            chrome.backgroundColor = .clear
            #if compiler(>=6.2)
            if #available(iOS 26.0, *) { chrome.effect = UIGlassEffect(style:.regular) }
            else { chrome.effect = UIBlurEffect(style:.systemMaterial) }
            #else
            chrome.effect = UIBlurEffect(style:.systemMaterial)
            #endif
        }
    }
}
@_cdecl("init_plugin_ios_reader")
func initPlugin() -> Plugin { IosReaderPlugin() }
