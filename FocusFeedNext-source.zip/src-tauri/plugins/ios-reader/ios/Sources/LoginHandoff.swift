import Foundation

/// Main-queue gate shared by controller dismissal and scene activation callbacks.
final class LoginHandoff {
    private var dismissed = false
    private var settled = false
    func didDismiss() { dismissed = true }
    func cancel() { settled = true }
    func finish(active: Bool) -> Bool {
        guard dismissed, active, !settled else { return false }
        settled = true
        return true
    }
}
