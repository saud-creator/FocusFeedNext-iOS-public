//! Standalone iOS provider. Network requests execute in an isolated native
//! WKWebView on x.com, using its cookie store and WebKit transport. No CLI
//! process, Windows host, remote relay, or credential-bearing frontend call.
use super::{ProviderCapabilities, XDataProvider};
use crate::{credentials::CredentialStore, models::*};
use serde_json::{json, Value};
use std::{collections::HashSet, sync::Arc};

#[cfg(target_os = "ios")]
static APP: std::sync::OnceLock<tauri::AppHandle> = std::sync::OnceLock::new();
#[cfg(target_os = "ios")]
pub fn initialize(app: tauri::AppHandle) { let _ = APP.set(app); }

pub fn native_call<T: serde::de::DeserializeOwned>(command: &str, args: Value) -> AppResult<T> {
    #[cfg(target_os = "ios")]
    {
        use tauri::Manager;
        let app = APP.get().ok_or_else(|| AppError::new(ErrorCode::ProviderUnavailable, "The native reader is not ready."))?;
        return app.state::<tauri_plugin_ios_reader::IosReader<tauri::Wry>>()
            .call(command, args).map_err(|message| AppError::new(ErrorCode::ProviderUnavailable, message));
    }
    #[cfg(not(target_os = "ios"))]
    { let _ = (command, args); Err(AppError::new(ErrorCode::BlockedOperation, "Native Twitter sign-in requires an iPhone.")) }
}

pub struct NativeIosProvider { store: Arc<dyn CredentialStore> }
impl NativeIosProvider {
    pub fn new(store: Arc<dyn CredentialStore>) -> Self { Self { store } }
    fn request(&self, operation: &str, variables: Value) -> AppResult<Value> {
        let credentials = self.store.load()?.ok_or_else(|| AppError::new(ErrorCode::NotAuthenticated, "Sign in to Twitter to load your feed."))?;
        // Plugin responses and errors are stripped of headers/cookies. Never log args.
        let result: Value = native_call("request", json!({"operation": operation, "variables": variables,
            "authToken": credentials.auth_token, "ct0": credentials.ct0}))?;
        response_body(result)
    }
    fn page(&self, operation: &str, max: u32, cursor: Option<String>, extra: Value) -> AppResult<FeedPage> {
        let mut variables = json!({"count": max.clamp(1, 60), "includePromotedContent": false,
            "withQuickPromoteEligibilityTweetFields": true, "withVoice": true, "withV2Timeline": true});
        if let Some(cursor) = cursor { variables["cursor"] = Value::String(cursor); }
        if let Some(extra) = extra.as_object() { for (key, value) in extra { variables[key] = value.clone(); } }
        parse_page(&self.request(operation, variables)?)
    }
    fn profile(&self, username: &str) -> AppResult<Author> {
        validate_username(username)?;
        let data = self.request("UserByScreenName", json!({"screen_name": username, "withSafetyModeUserFields": true}))?;
        parse_author(data.pointer("/data/user/result").ok_or_else(|| AppError::new(ErrorCode::ProviderUnavailable, "Twitter did not return this profile."))?)
    }
}
fn response_body(result: Value) -> AppResult<Value> {
    let status = result["status"].as_u64().unwrap_or(0);
    let body = result.get("body").cloned().unwrap_or(Value::Null);
    if status == 401 || status == 403 { return Err(AppError::new(ErrorCode::NotAuthenticated, "Twitter rejected this session. Sign in again.")); }
    if status == 429 { return Err(AppError::new(ErrorCode::RateLimited, "Twitter is limiting requests. Your loaded posts remain available; try again later.")); }
    if !(200..300).contains(&status) { return Err(AppError::new(ErrorCode::ProviderUnavailable, "Twitter could not complete this request. Try again.")); }
    if let Some(errors) = body["errors"].as_array() {
        if !errors.is_empty() {
            let code = errors[0]["code"].as_u64();
            return Err(AppError::new(if code == Some(88) { ErrorCode::RateLimited } else if matches!(code, Some(32 | 89 | 215)) { ErrorCode::NotAuthenticated } else { ErrorCode::ProviderUnavailable }, "Twitter returned an API error. Reconnect or try again later."));
        }
    }
    Ok(body)
}
impl XDataProvider for NativeIosProvider {
    fn name(&self) -> &'static str { "ios-direct" }
    fn capabilities(&self) -> ProviderCapabilities {
        ProviderCapabilities { feed_cursor: true, list_cursor: true, following_cursor: false,
            user_posts_cursor: true, promoted_flag: true, follow: true, unfollow: true,
            unbookmark: true, mute: false, block: false }
    }
    fn get_following_feed(&self, max: u32, cursor: Option<String>) -> AppResult<FeedPage> { self.page("HomeLatestTimeline", max, cursor, json!({})) }
    fn get_for_you_feed(&self, max: u32, cursor: Option<String>) -> AppResult<FeedPage> { self.page("HomeTimeline", max, cursor, json!({})) }
    fn get_user_profile(&self, username: &str) -> AppResult<Author> { self.profile(username) }
    fn get_user_posts(&self, username: &str, max: u32) -> AppResult<FeedPage> {
        self.get_user_posts_page(username, max, None)
    }
    fn get_user_posts_page(&self, username: &str, max: u32, cursor: Option<String>) -> AppResult<FeedPage> {
        let profile = self.profile(username)?;
        self.page("UserTweets", max, cursor, json!({"userId": profile.id}))
    }
    fn get_bookmarks_page(&self, max: u32, cursor: Option<String>) -> AppResult<FeedPage> { self.page("Bookmarks", max, cursor, json!({})) }
    fn get_bookmarks(&self, max: u32) -> AppResult<FeedPage> {
        let mut page = self.page("Bookmarks", max, None, json!({}))?;
        let mut seen: HashSet<String> = page.posts.iter().map(|p| p.id.clone()).collect();
        let mut cursors = HashSet::new();
        while page.posts.len() < max as usize {
            let Some(cursor) = page.cursor.clone() else { break };
            if !cursors.insert(cursor.clone()) { break; }
            let next = self.page("Bookmarks", (max as usize - page.posts.len()).min(60) as u32, Some(cursor), json!({}))?;
            page.cursor = next.cursor;
            page.posts.extend(next.posts.into_iter().filter(|p| seen.insert(p.id.clone())));
        }
        Ok(page)
    }
    fn get_following_accounts(&self, username: &str, max: u32) -> AppResult<Vec<Author>> {
        let profile = self.profile(username)?;
        let mut accounts = Vec::new();
        let mut cursor = None;
        let mut seen = HashSet::new();
        let mut cursors = HashSet::new();
        while accounts.len() < max.min(1000) as usize {
            let mut variables = json!({"userId": profile.id, "count": (max as usize - accounts.len()).min(60), "includePromotedContent": false});
            if let Some(value) = cursor { variables["cursor"] = Value::String(value); }
            let data = self.request("Following", variables)?;
            let mut next = None;
            walk(&data, &mut |node| {
                if node["cursorType"] == "Bottom" { next = node["value"].as_str().map(str::to_owned); }
                if let Some(user) = node.pointer("/user_results/result") {
                    if let Ok(author) = parse_author(user) { if seen.insert(author.id.clone()) { accounts.push(author); } }
                }
            });
            if next.is_none() || next.as_ref().is_some_and(|c| !cursors.insert(c.clone())) { break; }
            cursor = next;
        }
        accounts.truncate(max as usize);
        Ok(accounts)
    }
    fn get_list_timeline(&self, list_id: &str, max: u32) -> AppResult<FeedPage> { self.get_list_timeline_page(list_id, max, None) }
    fn get_list_timeline_page(&self, list_id: &str, max: u32, cursor: Option<String>) -> AppResult<FeedPage> {
        if list_id.is_empty() || !list_id.bytes().all(|b| b.is_ascii_digit()) { return Err(AppError::new(ErrorCode::BlockedOperation, "List ID must be numeric.")); }
        self.page("ListLatestTweetsTimeline", max, cursor, json!({"listId": list_id}))
    }
    fn get_current_user(&self) -> AppResult<Author> {
        let me = self.request("Me", json!({}))?;
        let user = me.pointer("/users/0").or_else(|| me.pointer("/0/user")).ok_or_else(|| AppError::new(ErrorCode::NotAuthenticated, "Twitter did not identify a signed-in account."))?;
        let username = user["screen_name"].as_str().ok_or_else(|| AppError::new(ErrorCode::NotAuthenticated, "Twitter did not identify a signed-in account."))?;
        self.profile(username)
    }
    fn status(&self) -> AppResult<AuthenticationStatus> {
        let account = self.get_current_user()?;
        Ok(AuthenticationStatus { authenticated: true, username: Some(account.username.clone()), account: Some(account), checked_at: chrono::Utc::now().to_rfc3339(), message: "Direct connection from this iPhone.".into() })
    }
    fn follow_account(&self, username: &str, _permit: &crate::security::WritePermit) -> AppResult<()> {
        validate_username(username)?;
        self.request("Follow", json!({"screen_name": username}))?; Ok(())
    }
    fn unfollow_account(&self, username: &str, _permit: &crate::security::WritePermit) -> AppResult<()> {
        validate_username(username)?;
        self.request("Unfollow", json!({"screen_name": username}))?; Ok(())
    }
    fn remove_bookmark(&self, id: &str, _permit: &crate::security::BookmarkPermit) -> AppResult<()> {
        if id.is_empty() || !id.bytes().all(|b| b.is_ascii_digit()) { return Err(AppError::new(ErrorCode::BlockedOperation, "Invalid post ID.")); }
        self.request("DeleteBookmark", json!({"tweet_id": id}))?; Ok(())
    }
}
fn string(value: &Value, key: &str) -> Option<String> { value[key].as_str().map(str::to_owned) }
fn validate_username(username: &str) -> AppResult<()> {
    if username.is_empty() || username.len() > 15 || !username.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_') {
        return Err(AppError::new(ErrorCode::BlockedOperation, "Invalid Twitter handle."));
    }
    Ok(())
}
fn date(value: &Value) -> Option<String> {
    let value = value.as_str()?;
    chrono::DateTime::parse_from_str(value, "%a %b %d %H:%M:%S %z %Y").ok().map(|d| d.to_rfc3339())
        .or_else(|| chrono::DateTime::parse_from_rfc3339(value).ok().map(|d| d.to_rfc3339()))
}
fn parse_author(raw: &Value) -> AppResult<Author> {
    let legacy = &raw["legacy"];
    let core = &raw["core"];
    let username = string(core, "screen_name").or_else(|| string(legacy, "screen_name")).ok_or_else(|| AppError::new(ErrorCode::ProviderUnavailable, "Profile data was incomplete."))?;
    let id = string(raw, "rest_id").or_else(|| string(legacy, "id_str")).ok_or_else(|| AppError::new(ErrorCode::ProviderUnavailable, "Profile ID was missing."))?;
    Ok(Author { id, username, display_name: string(core, "name").or_else(|| string(legacy, "name")).unwrap_or_default(),
        avatar_url: string(&raw["avatar"], "image_url").or_else(|| string(legacy, "profile_image_url_https")),
        banner_url: string(legacy, "profile_banner_url"), verified: raw["is_blue_verified"].as_bool().unwrap_or(false) || legacy["verified"].as_bool().unwrap_or(false),
        bio: string(legacy, "description"), followers_count: legacy["followers_count"].as_u64(), following_count: legacy["friends_count"].as_u64(),
        location: string(&raw["location"], "location").or_else(|| string(legacy, "location")),
        website: legacy.pointer("/entities/url/urls/0/expanded_url").and_then(Value::as_str).map(str::to_owned),
        joined_at: date(&core["created_at"]).or_else(|| date(&legacy["created_at"])), posts_count: legacy["statuses_count"].as_u64() })
}
fn media(raw: &Value) -> Vec<PostMedia> {
    let Some(rows) = raw.pointer("/legacy/extended_entities/media").and_then(Value::as_array) else { return Vec::new() };
    rows.iter().filter_map(|item| {
        let kind = match item["type"].as_str()? { "photo" => MediaKind::Image, "video" => MediaKind::Video, "animated_gif" => MediaKind::Gif, _ => return None };
        let width = item.pointer("/original_info/width").and_then(Value::as_u64).map(|v| v as u32);
        let height = item.pointer("/original_info/height").and_then(Value::as_u64).map(|v| v as u32);
        let mut variants: Vec<MediaVariant> = item.pointer("/video_info/variants").and_then(Value::as_array).into_iter().flatten().filter_map(|v| {
            if v["content_type"] != "video/mp4" { return None }
            let url = v["url"].as_str()?.to_string();
            let dimensions = url.split('/').find_map(|s| { let (w,h) = s.split_once('x')?; Some((w.parse::<u32>().ok()?,h.parse::<u32>().ok()?)) });
            let (w,h) = dimensions.map(|(w,h)|(Some(w),Some(h))).unwrap_or((None,None));
            let bitrate = v["bitrate"].as_u64();
            Some(MediaVariant { label: MediaVariant::label_for(w,h,bitrate).unwrap_or_else(|| "Original".into()), url, width: w, height: h, bitrate })
        }).collect();
        variants.sort_by_key(|v| std::cmp::Reverse(v.bitrate.unwrap_or(0)));
        let image = string(item, "media_url_https");
        let url = if kind == MediaKind::Image { image.clone()? } else { variants.first()?.url.clone() };
        Some(PostMedia { kind, url, preview_url: image, width, height, alt: string(item, "ext_alt_text"),
            duration_ms: item.pointer("/video_info/duration_millis").and_then(Value::as_u64), variants })
    }).collect()
}
fn parse_post(raw: &Value, promoted: bool) -> Option<Post> {
    let raw = raw.get("tweet").unwrap_or(raw);
    let repost = raw.pointer("/legacy/retweeted_status_result/result");
    let original = repost.unwrap_or(raw);
    let original = original.get("tweet").unwrap_or(original);
    let legacy = &original["legacy"];
    let author = parse_author(original.pointer("/core/user_results/result")?).ok()?;
    let id = string(original, "rest_id").or_else(|| string(legacy, "id_str"))?;
    let created_at = date(&legacy["created_at"])?;
    let text = original.pointer("/note_tweet/note_tweet_results/result/text").and_then(Value::as_str)
        .or_else(|| legacy["full_text"].as_str())?.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">");
    let quoted = original.pointer("/quoted_status_result/result").and_then(|q| {
        let q = q.get("tweet").unwrap_or(q);
        Some(Box::new(QuotedPost { id: string(q,"rest_id")?, text: string(&q["legacy"],"full_text")?,
            author: parse_author(q.pointer("/core/user_results/result")?).ok()?, created_at: date(&q["legacy"]["created_at"]), media: media(q), url: None }))
    });
    Some(Post { url: Some(format!("https://x.com/{}/status/{id}", author.username)), id, text, author, created_at,
        lang: string(legacy,"lang"), is_repost: repost.is_some(), reposted_by: if repost.is_some() { raw.pointer("/core/user_results/result").and_then(|v|parse_author(v).ok()) } else { None },
        is_promoted: promoted, quoted,
        metrics: PostMetrics { quotes: legacy["quote_count"].as_u64().unwrap_or(0), replies: legacy["reply_count"].as_u64().unwrap_or(0), reposts: legacy["retweet_count"].as_u64().unwrap_or(0), likes: legacy["favorite_count"].as_u64().unwrap_or(0),
            bookmarks: legacy["bookmark_count"].as_u64().unwrap_or(0), views: original.pointer("/views/count").and_then(|v|v.as_str().and_then(|s|s.parse().ok()).or_else(||v.as_u64())).unwrap_or(0) },
        media: media(original), is_article: original.get("article").is_some(), article_title: original.pointer("/article/article_results/result/title").and_then(Value::as_str).map(str::to_owned),
        in_reply_to: string(legacy,"in_reply_to_status_id_str"), provider: "ios-direct".into() })
}
fn walk(value: &Value, visitor: &mut impl FnMut(&Value)) {
    visitor(value);
    match value { Value::Object(values) => { for (key, value) in values { if key != "quoted_status_result" && key != "retweeted_status_result" { walk(value, visitor); } } }, Value::Array(values) => { for value in values { walk(value, visitor); } }, _ => {} }
}
fn parse_page(data: &Value) -> AppResult<FeedPage> {
    let mut posts = Vec::new(); let mut cursor = None; let mut seen = HashSet::new(); let mut has_instructions = false;
    walk(data, &mut |node| {
        if node.get("instructions").is_some() { has_instructions = true; }
        if node["cursorType"] == "Bottom" { cursor = node["value"].as_str().map(str::to_owned); }
        if let Some(result) = node.pointer("/itemContent/tweet_results/result") {
            let promoted = node.get("promotedMetadata").is_some() || node["itemContent"].get("promotedMetadata").is_some();
            if let Some(post) = parse_post(result, promoted) { if seen.insert(post.id.clone()) { posts.push(post); } }
        }
    });
    if !has_instructions { return Err(AppError::new(ErrorCode::ProviderUnavailable, "Twitter's timeline format changed. Update or reconnect the app.")); }
    Ok(FeedPage { posts, cursor, fetched_at: chrono::Utc::now().to_rfc3339(), provider: "ios-direct".into(), from_cache: false })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn rejects_auth_and_rate_limits_without_leaking_response() {
        for (status, expected) in [(401, ErrorCode::NotAuthenticated),(403, ErrorCode::NotAuthenticated),(429, ErrorCode::RateLimited)] {
            let error = response_body(json!({"status":status,"body":{"cookie":"secret"}})).unwrap_err();
            assert_eq!(error.code, expected); assert!(!error.message.contains("secret"));
        }
    }
    #[test] fn unknown_schema_is_not_an_empty_success() { assert!(parse_page(&json!({"data": {}})).is_err()); }
    #[test] fn parses_cursor_post_and_video_variants_without_quote_duplicates() {
        let author=json!({"rest_id":"1","legacy":{"screen_name":"reader","name":"Reader"}});
        let tweet=json!({"rest_id":"2","legacy":{"full_text":"hello &amp; مرحبا","created_at":"Fri Oct 09 12:00:00 +0000 2026","extended_entities":{"media":[{"type":"video","media_url_https":"https://pbs.twimg.com/a.jpg","original_info":{"width":720,"height":1280},"video_info":{"variants":[{"content_type":"video/mp4","bitrate":2000,"url":"https://video.twimg.com/720x1280/a.mp4"},{"content_type":"video/mp4","bitrate":1000,"url":"https://video.twimg.com/360x640/a.mp4"}]}}]}},"core":{"user_results":{"result":author}}});
        let data=json!({"data":{"home":{"instructions":[{"entries":[{"content":{"itemContent":{"tweet_results":{"result":tweet}}}},{"content":{"cursorType":"Bottom","value":"next"}}]}]}}});
        let page=parse_page(&data).unwrap(); assert_eq!(page.posts.len(),1); assert_eq!(page.cursor.as_deref(),Some("next"));
        assert_eq!(page.posts[0].text,"hello & مرحبا"); assert_eq!(page.posts[0].media[0].variants.len(),2); assert_eq!(page.posts[0].media[0].variants[0].label,"720p");
    }
}
